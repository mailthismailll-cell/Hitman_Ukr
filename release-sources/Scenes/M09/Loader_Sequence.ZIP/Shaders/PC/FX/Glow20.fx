#include "StandardCommon.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float  vFog:			FOG;
};

f2sStandard Ambient_PS10(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords=IN.vTexCoords;
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	OUT.col.rgb=IN.Diffuse.rgb*cTexel.rgb;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardAmbient10 AmbientHQ_VS10(a2vStandardHQ IN)
{
	v2fStandardAmbient10 OUT;
	
#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
	float2 vTexCoords=IN.vTexCoords;
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vVertexCol;
	float2 vTexCoords=IN.vTexCoords;
#endif
	
#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcTextureCoords(OUT.vTexCoords.xy,vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_VS10_PS10 < string Identifier="Ambient";  string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS10();
		PixelShader=compile ps_1_1 Ambient_PS10();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardAmbient10 AmbientRigid_VS10(a2vStandardRigid IN)
{
	v2fStandardAmbient10 OUT;
	
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vVertexCol;
	float2 vTexCoords=IN.vTexCoords;
	
	CalcTextureCoords(OUT.vTexCoords.xy,vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique AmbientRigid_VS10_PS10 < string Identifier="AmbientRigid";  string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientRigid_VS10();
		PixelShader=compile ps_1_1 Ambient_PS10();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

technique AmbientRigidHQ_VS10_PS10 < string Identifier="AmbientRigid";  string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientRigid_VS10();
		PixelShader=compile ps_1_1 Ambient_PS10();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardAmbient10 AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardAmbient10 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4Position=Do4MPS(IN.v4Position,i,w);
	float3 v3Normal=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3Tangent=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3Binormal=Do4MPS(tosigned(IN.v3Binormal),i,w);
	float4 v4Diffuse=IN.v4Diffuse;
	
	CalcTextureCoords(OUT.vTexCoords.xy,IN.vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_MPS_VS20_PS20 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_MPS_VS20();
		PixelShader=compile ps_2_0 Ambient_PS10();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#ifdef REFLECTIONENABLED

struct v2fStandardReflection {
	float4 Position:			POSITION;
	float4 Reflection:			COLOR0;
	float4 vTexCoords:			TEXCOORD0;
	float3 TangentToCubeSpace0: TEXCOORD1;
	float3 TangentToCubeSpace1: TEXCOORD2;
	float3 TangentToCubeSpace2: TEXCOORD3;
	float3 vEyeDirCubeSpace:	TEXCOORD4;
	float3 vEyeDirTangentSpace: TEXCOORD5;
	float vFog:					FOG;
};

f2sStandard Reflection_PS20(v2fStandardReflection IN) {
	
	f2sStandard OUT;

	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTangentSpace);
	
	float4 mask=tex2D(samplerReflectionMask,vTexCoords);
	float3 vNormalTangentSpace=CalculateBumpNormalPS(vTexCoords);
	float3 cFallOff=tex2D(samplerReflectionFallOff,1-saturate(IN.vEyeDirTangentSpace.z));

	// fetch the bump normal from the normal map
	float3 vNormalCubeSpace;
	vNormalCubeSpace.x=dot(IN.TangentToCubeSpace0,vNormalTangentSpace);
	vNormalCubeSpace.y=dot(IN.TangentToCubeSpace1,vNormalTangentSpace);
	vNormalCubeSpace.z=dot(IN.TangentToCubeSpace2,vNormalTangentSpace);
	float3 vReflected=reflect(-IN.vEyeDirCubeSpace,vNormalCubeSpace);
	
	float3 cReflect=texCUBE(samplerEnvironment,vReflected).rgb;
	
	OUT.col.rgb=mask.rgb*cReflect*IN.Reflection.rgb*cFallOff;
	OUT.col.a=IN.Reflection.a;
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardReflection Reflection_VS20(a2vStandardHQ IN) {

	v2fStandardReflection OUT;
	
	float4 v4Position = IN.v4Position;
	float3 v3Normal = tosigned(IN.v3Normal);

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),v3Normal);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-v4Position.xyz;
	OUT.vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=IN.vVertexCol*CalculateAlphaFade(v4Position.xyz,v3Normal);
	
	CalculateFog(OUT.vFog,v4Position.xyz);

	return OUT;
}

technique Reflection_VS20_PS20 < string Identifier="Reflection"; string Performance="Blend";> {
	
	pass p0 {
		VertexShader=compile vs_2_0 Reflection_VS20();
		PixelShader=compile ps_2_0 Reflection_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}

#endif //defined(MESH_STANDARD) || defined(MESH_TWEENED)

/////////////////////////////////////////////////

#if defined(MESH_RIGID)
v2fStandardReflection ReflectionRigid_VS20(a2vStandardRigid IN) {

	v2fStandardReflection OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-IN.v4Position.xyz;
	OUT.vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=IN.vVertexCol*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

technique ReflectionRigid_VS20_PS20 < string Identifier="ReflectionRigid"; string Performance="Blend";> {
	
	pass p0 {
		VertexShader=compile vs_2_0 ReflectionRigid_VS20();
		PixelShader=compile ps_2_0 Reflection_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif	//MESH_RIGID

#endif	//REFLECTIONENABLED