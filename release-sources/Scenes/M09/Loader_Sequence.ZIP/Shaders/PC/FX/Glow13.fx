#include "StandardCommon.fx"

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float  vFog:			FOG;
};

f2sStandard Ambient_PS10(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords=IN.vTexCoords;
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	OUT.col.rgb=IN.Diffuse.rgb*cTexel.rgb;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}


v2fStandardAmbient10 Ambient_VS10(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;
	
#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
	float2 vTexCoords=IN.vTexCoords;
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vVertexCol;
	float2 vTexCoords=IN.vTexCoords;
#endif
	
#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcTextureCoords(OUT.vTexCoords.xy,vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique Ambient_VS10_PS10 < string Identifier="Ambient";  string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS10();
		PixelShader=compile ps_1_1 Ambient_PS10();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif		
		TEXTURETRANSFORMFLAGS[0] = 0;
		TEXTURETRANSFORMFLAGS[1] = 0;
		TEXTURETRANSFORMFLAGS[2] = 0;
		TEXTURETRANSFORMFLAGS[3] = 0;
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

#ifdef REFLECTIONENABLED

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)

struct a2vGlowReflect1 {
	float4	v4Position:	POSITION;
	float2	vTexCoords:	TEXCOORD0;
};
		
struct v2fStandardReflection11_pass1 {
	float4 Position:	POSITION;
	float2 vTexCoords0:	TEXCOORD0;	//Texture coordinate 0 to sample map
};

v2fStandardReflection11_pass1 GlowReflectVS_pass1(a2vGlowReflect1 IN)
{
	v2fStandardReflection11_pass1 OUT;
	
	float4 v4Position=IN.v4Position;
	CalcPosition(OUT.Position,v4Position);

	float2 vTexCoords=IN.vTexCoords;
	CalcTextureCoords(OUT.vTexCoords0.xy,vTexCoords.xy);
	
	return OUT;
}

struct a2vGlowReflect2 {
	float4	v4Position:	POSITION;
	float2	vTexCoords:	TEXCOORD0;
	float4	vVertexCol:	COLOR0;
	float3	v3Tangent:	TANGENT;
	float3	v3Binormal:	BINORMAL;
	float3	v3Normal:	NORMAL;
};
		
struct v2fStandardReflection11_pass2 {
	float4 Position:	POSITION;
	float4 Reflection:	COLOR0;
	float3 vTexCoords0:	TEXCOORD0;	//Texture coordinate 0 is normal
	float4 vTexCoords1:	TEXCOORD1;	//Texture coordinate sets 1, 2, and 3 are the rows of the 3�3 matrix
	float4 vTexCoords2:	TEXCOORD2;
	float4 vTexCoords3:	TEXCOORD3;
};

v2fStandardReflection11_pass2 GlowReflectVS_pass2(a2vGlowReflect2 IN)
{
	v2fStandardReflection11_pass2 OUT;
	
	float4 v4Position=IN.v4Position;
	CalcPosition(OUT.Position,v4Position);

	OUT.vTexCoords0.xyz=float3(0,0,1);
			
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	vEyeDirCubeSpace=normalize(vEyeDirCubeSpace);
	
	// And move colors over and alphafade
	OUT.Reflection=IN.vVertexCol*CalculateAlphaFade(v4Position.xyz,IN.v3Normal);
	
	float3 TangentToCubeSpace0=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	float3 TangentToCubeSpace1=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	float3 TangentToCubeSpace2=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	OUT.vTexCoords1=float4(TangentToCubeSpace0.xyz,vEyeDirCubeSpace.x);
	OUT.vTexCoords2=float4(TangentToCubeSpace1.xyz,vEyeDirCubeSpace.y);
	OUT.vTexCoords3=float4(TangentToCubeSpace2.xyz,vEyeDirCubeSpace.z);
	
	return OUT;
}

technique Reflection_VS11_PS11 < string Identifier="Reflection"; string Performance="Fastest";> {
	pass pass1 {
		VertexShader=compile vs_1_1 GlowReflectVS_pass1();
		PixelShader=asm {//<GlowReflectPS_pass1>;
			ps.1.1
			tex t0					; falloff map
			mov r0, t0
		};
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=One;
		DestBlend=Zero;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=Alpha;
		
		texture[0] =<mapReflectionFallOff>;
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=CLAMP;
		AddressV[0]=CLAMP;
		AddressW[0]=CLAMP;
	}
	pass pass2 {
		VertexShader=compile vs_1_1 GlowReflectVS_pass2();
		PixelShader=asm {//<GlowReflectPS_pass2>;
			ps.1.1
			
			texcoord t0					; normal
			texm3x3pad t1, t0			; Perform first row of matrix multiply.
			texm3x3pad t2, t0			; Perform second row of matrix multiply.
			texm3x3vspec t3, t0			; Perform third row of matrix multiply, sample

			mul r0, t3, v0				//OUT.col.a=1;
			//OUT.col.rgb=mask.rgb*cReflect*IN.Reflection.rgb;
		};
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=DestAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=RED|GREEN|BLUE;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif
		MinFilter[0]=LINEAR;
		MagFilter[0]=LINEAR;
		MipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;
		
		Texture[3] =<mapEnvironment>;
		MinFilter[3]=LINEAR;
		MagFilter[3]=LINEAR;
		MipFilter[3]=LINEAR;
		AddressU[3]=WRAP;
		AddressV[3]=WRAP;
		AddressW[3]=WRAP;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif	//#if defined(MESH_STANDARD) || defined(MESH_TWEENED)

#if defined(MESH_RIGID)

v2fStandardReflection11 ReflectionRigid_VS11(a2vStandardRigid IN) {

	v2fStandardReflection11 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	OUT.vTexCoords1=OUT.vTexCoords0;

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	float3 TangentToCubeSpace0=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	float3 TangentToCubeSpace1=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	float3 TangentToCubeSpace2=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=IN.vVertexCol*CalculateAlphaFade(v4Position.xyz,v3Normal);
	
	float3 vNormalCubeSpace;
	vNormalCubeSpace.x=dot(TangentToCubeSpace0,float3(0,0,1));
	vNormalCubeSpace.y=dot(TangentToCubeSpace1,float3(0,0,1));
	vNormalCubeSpace.z=dot(TangentToCubeSpace2,float3(0,0,1));
	normalize(OUT.vTexCoordsCube=reflect(-vEyeDirCubeSpace,vNormalCubeSpace));
	
	float vTexCoordsFalloff=normalize(mul(m33TangentSpace,vEyeDir)).z;
	vTexCoordsFalloff=1-saturate(vTexCoordsFalloff);
	OUT.vTexCoordsFalloff=float2(vTexCoordsFalloff,0);

	return OUT;
}

technique ReflectionRigid_VS11_PS11 < string Identifier="ReflectionRigid"; string Performance="Fastest";> {
	pass pass1 {
		VertexShader=compile vs_1_1 GlowReflectVS_pass1();		//ReflectionRigid_VS11();
		PixelShader=asm {//<GlowReflectPS_pass1>;
			ps.1.1
			tex t0					; falloff map
			mov r0, t0
		};
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=One;
		DestBlend=Zero;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=Alpha;
		
		texture[0] =<mapReflectionFallOff>;
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=CLAMP;
		AddressV[0]=CLAMP;
		AddressW[0]=CLAMP;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
	pass pass2 {
		VertexShader=compile vs_1_1 GlowReflectVS_pass2();
		PixelShader=asm {//<GlowReflectPS_pass2>;
			ps.1.1
			
			texcoord t0					; normal
			texm3x3pad t1, t0			; Perform first row of matrix multiply.
			texm3x3pad t2, t0			; Perform second row of matrix multiply.
			texm3x3vspec t3, t0			; Perform third row of matrix multiply, sample

			mul r0, t3, v0				//OUT.col.a=1;
			//OUT.col.rgb=mask.rgb*cReflect*IN.Reflection.rgb;
		};
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=DestAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=RED|GREEN|BLUE;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif
		MinFilter[0]=LINEAR;
		MagFilter[0]=LINEAR;
		MipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;
		
		Texture[3] =<mapEnvironment>;
		MinFilter[3]=LINEAR;
		MagFilter[3]=LINEAR;
		MipFilter[3]=LINEAR;
		AddressU[3]=WRAP;
		AddressV[3]=WRAP;
		AddressW[3]=WRAP;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif	//MESH_RIGID

#endif	//REFLECTIONENABLED