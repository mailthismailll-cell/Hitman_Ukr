#include "StandardCommon.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD)
struct v2fStandardAmbientHQ20 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 Specular:			COLOR1;
	float4 vTexCoords:			TEXCOORD0;
	float4 vTexCoordsProj:		TEXCOORD1;
	float3 vLightDirTS:			TEXCOORD2;
	float3 vEyeDirTS:			TEXCOORD3;
	float vFog:					FOG;
};

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=mul(m33TangentSpace,vEyeDirOS);

	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a;
#ifdef SPECULARENABLED
	OUT.Specular=IN.vLightCol*v4SpecularColor;
#else
	OUT.Specular=v4DiffuseColor;
#endif
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,IN.v4Position);
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	OUT.col.rgb=0;

		
	float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	float3 vLightDirTS=normalize(IN.vLightDirTS);
	float3 vHalfDir=normalize(vEyeDirTS+vLightDirTS);
	
	// Ambient
	float3 cAmbient=0;//IN.Ambient.rgb*cTexel.rgb;
	// Diffuse
	float3 cDiffuse=saturate(dot(vLightDirTS,v3BumpNormal))*IN.Diffuse.rgb*cTexel.rgb*2;
	
#ifdef SPECULARENABLED
	// Specular
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	OUT.col.rgb+=v3SpecularColor*2;
#endif
	
#ifdef REFRACTION2DENABLED
	float fCosAngleEye=abs(dot(v3BumpNormal,vEyeDirTS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
	
	// @hs Optimize to be a tex2DProj(coords+offset*coords.w instead
	float2 vCoords=IN.vTexCoordsProj.xy/IN.vTexCoordsProj.w;
	
	//float4 cMaskR=float4(1,0,0,1);
	//float4 cMaskG=float4(0,1,0,1);
	//float4 cMaskB=float4(0,0,1,1);
	
	float4 cRefract,cRefractOrig,cRefractDistortR,cRefractDistortG,cRefractDistortB;
	float2 vRefractOffset=v3BumpNormal.xy*gm_vRefraction2DScale;
	cRefractDistortR=tex2D(samplerRefraction2D,vCoords-vRefractOffset*1.00);
	//cRefractDistortG=tex2D(samplerRefraction2D,vCoords-vRefractOffset*0.80);
	//cRefractDistortB=tex2D(samplerRefraction2D,vCoords-vRefractOffset*0.60);
	cRefractOrig=tex2D(samplerRefraction2D,vCoords);
	if (cRefractDistortR.a > 0.9)
		//cRefract = cRefractDistortR*cMaskR+cRefractDistortG*cMaskG+cRefractDistortB*cMaskB;
		cRefract = cRefractDistortR; //@hs Need to make special version for ps3 (out of instructions here)
	else
		cRefract = cRefractOrig;
	float4 cRefractMask=tex2D(samplerRefraction2DMask,vTexCoords);
	OUT.col.rgb+=lerp(cRefract*gm_vRefraction2DColor*cRefractMask.rgb,cAmbient+cDiffuse,cTexel.a);
#endif

	OUT.col.a=1;
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

struct v2fStandardAmbient00 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 vTexCoords:			TEXCOORD0;
	float4 vTexCoordsProj:		TEXCOORD1;
	float vFog:					FOG;
};

v2fStandardAmbient00 Ambient_VS00(a2vStandard IN)
{
	v2fStandardAmbient00 OUT;
	
//	float3x3 m33TangentSpace;
//	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
//	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
//	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
//	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
//	OUT.vEyeDirTS=mul(m33TangentSpace,vEyeDirOS);

	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a;
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,IN.v4Position);
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_VS00_PS00 < string Identifier="Ambient"; string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS00();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=TEXTURE;
		AlphaOp[0]=SELECTARG1;
		AlphaArg1[0]=DIFFUSE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;	
		AlphaOp[1]=DISABLE;
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif


//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
struct v2fStandardAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float3 vLightDir1TS:	COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float4 vTexCoordsProj:	TEXCOORD1;
	float3 vLightDir2TS:	TEXCOORD2;
	float3 vLightDir3TS:	TEXCOORD3;
	float3 vHalfDir1TS:		TEXCOORD4;
	float3 vHalfDir2TS:		TEXCOORD5;
	float3 vHalfDir3TS:		TEXCOORD6;
	float3 vEyeDirTS:		TEXCOORD7;
	float vFog:				FOG;
};

f2sStandard AmbientHQ_MPS_PS20(v2fStandardAmbientMPSHQ IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;//=IN.vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDir1TS=tosigned(IN.vLightDir1TS);
	float3 vLightDir2TS=IN.vLightDir2TS;
	float3 vLightDir3TS=IN.vLightDir3TS;
	OUT.col.rgb =v4BonesLights[1].rgb*saturate(dot(vLightDir1TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[3].rgb*saturate(dot(vLightDir2TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[5].rgb*saturate(dot(vLightDir3TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[6].rgb;
	OUT.col.rgb*=IN.Diffuse.rgb*cTexel.rgb*v4DiffuseColor*2;
	
#ifdef REFRACTION2DENABLED
	//float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	float3 vEyeDirTS=IN.vEyeDirTS;
	float fCosAngleEye=abs(dot(v3BumpNormal,vEyeDirTS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
	
	// @hs Optimize to be a tex2DProj(coords+offset*coords.w instead
	float2 vCoords=IN.vTexCoordsProj.xy/IN.vTexCoordsProj.w;
	
	//float4 cMaskR=float4(1,0,0,1);
	//float4 cMaskG=float4(0,1,0,1);
	//float4 cMaskB=float4(0,0,1,1);
	float4 cRefract,cRefractOrig,cRefractDistortR,cRefractDistortG,cRefractDistortB;
	float2 vRefractOffset=v3BumpNormal.xy*gm_vRefraction2DScale;
	cRefractDistortR=tex2D(samplerRefraction2D,vCoords-vRefractOffset);
	//cRefractDistortG=tex2D(samplerRefraction2D,vCoords-vRefractOffset*0.80);
	//cRefractDistortB=tex2D(samplerRefraction2D,vCoords-vRefractOffset*0.60);
	cRefractOrig=tex2D(samplerRefraction2D,vCoords);
	if (cRefractDistortR.a > 0.9)
		//cRefract = cRefractDistortR*cMaskR+cRefractDistortG*cMaskG+cRefractDistortB*cMaskB;
		cRefract = cRefractDistortR;
	else
		cRefract = cRefractOrig;
	float4 cRefractMask=tex2D(samplerRefraction2DMask,vTexCoords);
	// Lerp between diffuse color and refraction color
	OUT.col.rgb=lerp(cRefract*gm_vRefraction2DColor*cRefractMask.rgb,OUT.col.rgb,cTexel.a);
#endif
	
#ifdef SPECULARENABLED
	float3 vHalfDir1=normalize(IN.vHalfDir1TS);
	float3 vHalfDir2=normalize(IN.vHalfDir2TS);
	float3 vHalfDir3=normalize(IN.vHalfDir3TS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float3 vSpecular1=v4BonesLights[1].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir1)),v4SpecularPower.x);
	float3 vSpecular2=v4BonesLights[3].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir2)),v4SpecularPower.x);
	float3 vSpecular3=v4BonesLights[5].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir3)),v4SpecularPower.x);
	float3 vSpecular=vSpecular1+vSpecular2+vSpecular3;
	float3 v3SpecularColor=vSpecular*v3SpecularMask*vSpecularLevel*v4SpecularColor;
	OUT.col.rgb+=v3SpecularColor*2;
#endif

	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}
#endif

#if defined(MESH_RIGID)
v2fStandardAmbientMPSHQ AmbientHQ_Rigid_VS20(a2vStandardRigid IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.vLightDir1TS=tounsigned(OUT.vLightDir1TS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,v4EyePosObject-IN.v4Position));
	OUT.Diffuse.rgb=IN.vVertexCol.rgb;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,IN.v4Position);
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_Rigid_VS20_PS20 < string Identifier="AmbientRigid"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_Rigid_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardAmbientMPSHQ AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,v4PositionOut);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.vEyeDirTS=mul(m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;

	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,v4PositionOut);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
//#ifdef PARALLAXENABLED
	OUT.vTexCoords.zw=0;
	//CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
//#endif

	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

technique AmbientHQ_MPS_VS20_PS20 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_MPS_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif



//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fGlassRefractionMask {
	float4 Position:		POSITION;
};
v2fGlassRefractionMask GlassRefractionMask_VS20(a2vStandardHQ IN)
{
	v2fGlassRefractionMask OUT;
	CalcPosition(OUT.Position, IN.v4Position);
	return OUT;
}
f2sStandard GlassRefractionMask_PS11(v2fGlassRefractionMask IN) 
{
	f2sStandard OUT;
	OUT.col.rgb = float3(0,0,0);
	OUT.col.a=1;
	return OUT;
}
technique GlassRefractionMaskHQ_VS20_PS20 < string Identifier="RefractionMask"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 GlassRefractionMask_VS20();
		PixelShader=compile ps_1_1 GlassRefractionMask_PS11();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}

technique GlassRefractionMaskHQ_VS00_PS00 < string Identifier="RefractionMask"; string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 GlassRefractionMask_VS20();
		PixelShader=NULL;
		
		ColorOp[0]=SUBTRACT;	//will give us zero
		ColorArg1[0]=SPECULAR;
		ColorArg2[0]=SPECULAR;
		AlphaOp[0]=ADD;			//saturates to one
		AlphaArg1[0]=SPECULAR;
		AlphaArg2[0]=SPECULAR;
		
		ColorOp[1]=DISABLE;	
		AlphaOp[1]=DISABLE;

		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}
