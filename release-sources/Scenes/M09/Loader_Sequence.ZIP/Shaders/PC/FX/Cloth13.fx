#include "standardcommon.fx"
/*
	Description:
		cloth shader 
		this is based on the skin shader, it does not support subsurface scattering
	Features:
		* Support for skinned models
	Author:
		Kasper Storm
*/

// Application to Vertex defined by material class
struct a2vCloth {
    float4 v4Position	: POSITION;
    float3 v3Normal		: NORMAL;
	float4 v4Diffuse	: COLOR0;
	float4 vLightDir	: COLOR1;
	float2 v2TexCoord	: TEXCOORD0;
	float3 v3Tangent	: TANGENT;
	float3 v3Binormal	: BINORMAL;
};

struct a2vClothMPS {
	float4	v4Position:	POSITION;
	float4	v4Weights:	BLENDWEIGHT;
	int4	v4Indices:	BLENDINDICES;
	float3	v3Normal:	NORMAL;
	float4	v4Diffuse:	COLOR0;
	float2	v2TexCoord:	TEXCOORD0;
	float3	v3Tangent:	TANGENT;
	float3	v3Binormal:	BINORMAL;
};

// Fragment to surface
struct f2sCloth {
	float4 col:		COLOR0;
};

/****************************************************************
		Ambient pass
 ****************************************************************/
struct v2fClothAmbient {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
	float vFog:			FOG;
};

f2sCloth Ambient_PS11(v2fClothAmbient IN) 
{
	f2sCloth OUT;

	float4 cTexel=tex2D(samplerDiffuse,IN.TexDiffuse.xy);
	OUT.col.rgb=2*IN.Diffuse.rgb*cTexel.rgb;
	OUT.col.a=CalculateAlpha(2*IN.Diffuse.a*cTexel.a);
	
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
v2fClothAmbient Ambient_VS11(a2vCloth IN)
{
	v2fClothAmbient OUT;	
	CalcPosition(OUT.Position, IN.v4Position);
	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);	
	OUT.TexDiffuse=IN.v2TexCoord;
	OUT.Diffuse.rgb=CalculateDebugColor(IN.v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=CalculateAlpha(IN.v4Diffuse.a);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

technique Ambient_VS11_PS11 < string Identifier="Ambient"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fClothAmbient AmbientMPS_VS11(a2vClothMPS IN)
{
	v2fClothAmbient OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(IN.v3Normal,i,w);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	OUT.TexDiffuse=IN.v2TexCoord;
	
	float3 vDiffuse=CalcBonesLight(v3NormalOut,IN.v4Diffuse.rgb);
	OUT.Diffuse.rgb=CalculateDebugColor(vDiffuse.rgb*v4DiffuseColor.rgb)*0.5;
	OUT.Diffuse.a=CalculateAlpha(IN.v4Diffuse.a*0.5);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

technique AmbientMPS_VS11_PS11 < string Identifier="AmbientMPS"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 AmbientMPS_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// lighting pass
//////////////////////////////////////////////////////////////////

struct v2fClothDiffuse {
    float4 Position     : POSITION;
	float4 Diffuse		: COLOR0;
	float4 Specular		: COLOR1;

	float2 vTexCoords	: TEXCOORD0;
    float2 vTexCoords2  : TEXCOORD1;
    float3 HalfVector	: TEXCOORD2;
    float3 LightVector	: TEXCOORD3;
	float vFog:			  FOG;
};

/****************************************************************
		DiffuseBumpSpecularRimLight_PS11
 ****************************************************************/
float4 DiffuseBumpSpecularRimLight_PS11(v2fClothDiffuse IN) : COLOR0 
{
	float4 OUT;

	// sampling stage
	float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
	float3 bumpnormal = CalculateBumpNormalPS11(IN.vTexCoords2); 
	
	// add the diffuse lighting contribution
	float  diffuse  = saturate(dot(bumpnormal, IN.LightVector));
	OUT.rgb = diffuse * color.xyz;
	OUT.rgb *= IN.Diffuse;
/*	
#ifdef SPECULARENABLED
//	float3 gloss = tex2D(samplerSpecularMask,IN.vTexCoords);
	float  specular = pow(saturate(dot(bumpnormal, IN.HalfVector)),v4SpecularPower.x)* vSpecularLevel;
	OUT.rgb += IN.Specular * v4SpecularColor.xyz * specular;// * gloss;
#endif
	
	// light and shadow factor
	//OUT.rgb *= CalculateLightIntensity11(IN.TexLightClip,IN.LightVectorOS);
	//OUT.rgb *= GetShadowMapPS11(IN.TexShadow);
*/
	OUT.a = CalculateAlpha(color.a*IN.Diffuse.a);
	
	return OUT;
}


void CalculateLightingVS11(out float3 vLightDirTSOut, out float3 vHalfDirTSOut, float4 vPosition, float3x3 m33TangentSpace) {

	// Calculate diffuse term
	float3 vLightDirObject=v4LightPosObject.xyz-vPosition.xyz;
	float3 v3EyeDirObject=v4EyePosObject.xyz-vPosition.xyz;
	float3 vLightDirTangentSpace=mul(m33TangentSpace,vLightDirObject);
	float3 vEyeDirTangentSpace=mul(m33TangentSpace,v3EyeDirObject);
	vLightDirTSOut=normalize(vLightDirTangentSpace.xyz);
	
	// Calculate specular term
#ifdef SPECULARENABLED
	// Output half angle vector for specular term
	vHalfDirTSOut=normalize(vEyeDirTangentSpace)+vLightDirTSOut;
#else
	vHalfDirTSOut=vLightDirTSOut; // Term not used - but binding currently needed from VS->PS
#endif
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
/****************************************************************
		DiffuseBumpSpecularRimLight_VS11
 ****************************************************************/
v2fClothDiffuse DiffuseBumpSpecularRimLight_VS11(a2vStandard IN) {
	v2fClothDiffuse OUT;
	CalcPosition(OUT.Position,IN.v4Position);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS11(OUT.LightVector,OUT.HalfVector,IN.v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	OUT.vTexCoords2=OUT.vTexCoords;
	return OUT;
}
  
/****************************************************************
		DiffuseBumpSpecularRimLight
 ****************************************************************/
technique DiffuseBumpSpecularRimLight < string Identifier="DiffuseBumpSpecularRimLight"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 DiffuseBumpSpecularRimLight_VS11();
		PixelShader=asm {		//compile  ps_1_1 DiffuseBumpSpecularRimLight_PS11();
			ps.1.1
			def c0,0,0,1,1
			def c5,0,0,1,0
			tex t0		//samplerDiffuse
#ifdef BUMPENABLED
			tex t1		//samplerNormal
#endif
			texcoord t2	//HalfVector
			texcoord t3	//LightVector
						
#ifdef BUMPENABLED		
			add_sat r0.rgb, t1, c5		//force z to 1
			
			dp3_sat r1.rgb, r0, r0		//"normalize"
			mad_d2	r1.rgb, r0, 1-r1, r0//_d2
			
			dp3_sat r1.rgb,	r1, t3	// bumpnormal = tex2D(samplerNormal,v2Coords).rgb*v4BumpScale;
#else
			//float3 vNormal=float3(0,0,1);
			dp3_sat r1.rgb, c0, t3
#endif
			//float  diffuse  = saturate(dot(bumpnormal, IN.LightVector));
			//float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
			//OUT.rgb = diffuse * color.xyz;
			mul r0.rgb, t0, r1
			+mul r0.a, v0.a, t0.a	//color.a*IN.Diffuse.a
			
			//OUT.rgb *= IN.Diffuse;
			mul r0.rgb, r0, v0
			
#ifdef SPECULARENABLED
		//	float  specular = pow(saturate(dot(bumpnormal, IN.HalfVector)),v4SpecularPower.x)* vSpecularLevel;
//			dp3_sat r1.rgb, r1, t2
		
		//	OUT.rgb += IN.v4SpecularColor.xyz * specular;
//			mad r0.rgb, r0, r1
#endif
		
#ifndef BLENDENABLED
			+mov r0.a, c1.a
#endif
			//+lrp r0.a, c1.a, r0.a, c0.a	//return lerp(1,fAlphaIn,BlendEnabled);
		};
		//PixelShaderConstant[0] is reserved
		//PixelShaderConstant[1]=<BlendEnabled>;
		//PixelShaderConstant[2]=<v4SpecularPower>;
		//PixelShaderConstant[3]=<vSpecularLevel>;
		//PixelShaderConstant[4]=<v4SpecularColor>;
		//PixelShaderConstant[5] is reserved
		
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0]=0;
#ifdef BUMPENABLED	
		Texture[1] = <mapNormal>;		//samplerNormal
		TEXTURETRANSFORMFLAGS[1]=0;
#endif	
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		SpecularEnable=true;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)

/****************************************************************
		DiffuseBumpSpecularRimLightMPS_VS11
 ****************************************************************/
v2fClothDiffuse DiffuseBumpSpecularRimLightMPS_VS11(a2vStandardMPS IN)
{
	v2fClothDiffuse OUT;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS11(OUT.LightVector,OUT.HalfVector,v4PositionOut,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	OUT.vTexCoords2=OUT.vTexCoords;
	return OUT;
}

/****************************************************************
		DiffuseBumpSpecularRimLightMPS
 ****************************************************************/
technique DiffuseBumpSpecularRimLightMPS < string Identifier="DiffuseBumpSpecularRimLightMPS"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 DiffuseBumpSpecularRimLightMPS_VS11();
		PixelShader=asm {		//compile  ps_1_1 DiffuseBumpSpecularRimLight_PS11();
			ps.1.1
			def c0,0,0,1,1
			def c5,0,0,1,0
			tex t0		//samplerDiffuse
#ifdef BUMPENABLED
			tex t1		//samplerNormal
#endif
			texcoord t2	//HalfVector
			texcoord t3	//LightVector
					
#ifdef BUMPENABLED
			add_sat r0.rgb, t1, c5		//force z to 1
			
			dp3_sat r1.rgb, r0, r0		//"normalize"
			mad_d2	r1.rgb, r0, 1-r1, r0//_d2
			
			dp3_sat r1.rgb,	r1, t3	// bumpnormal = tex2D(samplerNormal,v2Coords).rgb*v4BumpScale;
#else
			//float3 vNormal=float3(0,0,1);
			dp3_sat r1.rgb, c0, t3
#endif
			//float  diffuse  = saturate(dot(bumpnormal, IN.LightVector));
			//float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
			//OUT.rgb = diffuse * color.xyz;
			mul r0.rgb, t0, r1
			+mul r0.a, v0.a, t0.a	//color.a*IN.Diffuse.a
			
			//OUT.rgb *= IN.Diffuse;
			mul r0.rgb, r0, v0
			
		#ifdef SPECULARENABLED
		//	float  specular = pow(saturate(dot(bumpnormal, IN.HalfVector)),v4SpecularPower.x)* vSpecularLevel;
//			dp3_sat r1.rgb, r1, t2
		
		//	OUT.rgb += IN.v4SpecularColor.xyz * specular;
//			mad r0.rgb, r0, r1
		#endif
		
#ifndef BLENDENABLED
			+mov r0.a, c1.a
#endif
			//+lrp r0.a, c1.a, r0.a, c0.a	//return lerp(1,fAlphaIn,BlendEnabled);
		};
		//PixelShaderConstant[0] is reserved
		//PixelShaderConstant[1]=<BlendEnabled>;
	//	PixelShaderConstant[2]=<v4SpecularPower>;
	//	PixelShaderConstant[3]=<vSpecularLevel>;
	//	PixelShaderConstant[4]=<v4SpecularColor;
		//PixelShaderConstant[5] is reserved
		
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0]=0;
#ifdef BUMPENABLED
		Texture[1] = <mapNormal>;		//samplerNormal
		TEXTURETRANSFORMFLAGS[1]=0;
#endif
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
