///
/// Prefix notation
///
/// gm_xxx - Global Material defined value
/// go_xxx - Global Object defined value
/// gi_xxx - Global internal defined value

///
/// Parameters available from common.mcd
///


////////////////////////////////////////////////////////////////////////////////////////////////////////
float4 v4DiffuseColor;

int gm_mapDiffuseMinFilter=2;
int gm_mapDiffuseMagFilter=2;
int gm_mapDiffuseMipFilter=2;
int gm_mapDiffuseAddressU=1;
int gm_mapDiffuseAddressV=1;
int gm_mapDiffuseAddressW=1;
int gm_mapDiffuseMaxAnisotropy=1;

texture mapDiffuse;
sampler samplerDiffuse = sampler_state {
	texture =<mapDiffuse>;
	minFilter=<gm_mapDiffuseMinFilter>;
	magFilter=<gm_mapDiffuseMagFilter>;
	mipFilter=<gm_mapDiffuseMipFilter>;
	AddressU=<gm_mapDiffuseAddressU>;
	AddressV=<gm_mapDiffuseAddressV>;
	AddressW=<gm_mapDiffuseAddressW>;
	MaxAnisotropy=<gm_mapDiffuseMaxAnisotropy>;
};

// Used by the sprite material class only - to be moved
int gm_mapDiffuseMaskMinFilter=2;
int gm_mapDiffuseMaskMagFilter=2;
int gm_mapDiffuseMaskMipFilter=2;
int gm_mapDiffuseMaskAddressU=1;
int gm_mapDiffuseMaskAddressV=1;
int gm_mapDiffuseMaskAddressW=1;

texture mapDiffuseMask;
sampler samplerDiffuseMask = sampler_state {
	texture =<mapDiffuseMask>;
	minFilter=<gm_mapDiffuseMaskMinFilter>;
	magFilter=<gm_mapDiffuseMaskMagFilter>;
	mipFilter=<gm_mapDiffuseMaskMipFilter>;
	AddressU=<gm_mapDiffuseMaskAddressU>;
	AddressV=<gm_mapDiffuseMaskAddressV>;
	AddressW=<gm_mapDiffuseMaskAddressW>;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef BUMPENABLED

float4 v4BumpScale;

int gm_mapNormalMinFilter=2;
int gm_mapNormalMagFilter=2;
int gm_mapNormalMipFilter=2;
int gm_mapNormalAddressU=1;
int gm_mapNormalAddressV=1;
int gm_mapNormalAddressW=1;

texture mapNormal;
sampler samplerNormal = sampler_state {
	texture =<mapNormal>;
	minFilter=<gm_mapNormalMinFilter>;
	magFilter=<gm_mapNormalMagFilter>;
	mipFilter=<gm_mapNormalMipFilter>;
	AddressU=<gm_mapNormalAddressU>;
	AddressV=<gm_mapNormalAddressV>;
	AddressW=<gm_mapNormalAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef BUMPDETAILENABLED

float4 v4BumpDetailScale;
float4 vBumpDetailTileFactor;

int gm_mapNormalDetailMinFilter=2;
int gm_mapNormalDetailMagFilter=2;
int gm_mapNormalDetailMipFilter=2;
int gm_mapNormalDetailAddressU=1;
int gm_mapNormalDetailAddressV=1;
int gm_mapNormalDetailAddressW=1;

texture mapNormalDetail;
sampler samplerNormalDetail = sampler_state {
	texture =<mapNormalDetail>;
	minFilter=<gm_mapNormalDetailMinFilter>;
	magFilter=<gm_mapNormalDetailMagFilter>;
	mipFilter=<gm_mapNormalDetailMipFilter>;
	AddressU=<gm_mapNormalDetailAddressU>;
	AddressV=<gm_mapNormalDetailAddressV>;
	AddressW=<gm_mapNormalDetailAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef PARALLAXENABLED

float vParallaxScale;
float vParallaxBias;

int gm_mapParallaxMinFilter=2;
int gm_mapParallaxMagFilter=2;
int gm_mapParallaxMipFilter=2;
int gm_mapParallaxAddressU=1;
int gm_mapParallaxAddressV=1;
int gm_mapParallaxAddressW=1;

texture mapParallax;
sampler samplerParallax = sampler_state {
	texture =<mapParallax>;
	minFilter=<gm_mapParallaxMinFilter>;
	magFilter=<gm_mapParallaxMagFilter>;
	mipFilter=<gm_mapParallaxMipFilter>;
	AddressU=<gm_mapParallaxAddressU>;
	AddressV=<gm_mapParallaxAddressV>;
	AddressW=<gm_mapParallaxAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef WOBBLEENABLED
	float fWobbleUSpeed;
	float fWobbleVSpeed;
	float fWobblePosAmplitude;
	float fWobbleNorAmplitude;
	float fWobbleWaveLength;
#endif

#ifdef SPECULARENABLED

float4 v4SpecularColor;
float4 v4SpecularPower;
float vSpecularLevel;

int gm_mapSpecularMaskMinFilter=2;
int gm_mapSpecularMaskMagFilter=2;
int gm_mapSpecularMaskMipFilter=2;
int gm_mapSpecularMaskAddressU=1;
int gm_mapSpecularMaskAddressV=1;
int gm_mapSpecularMaskAddressW=1;

texture mapSpecularMask;
sampler samplerSpecularMask = sampler_state {
	texture =<mapSpecularMask>;
	minFilter=<gm_mapSpecularMaskMinFilter>;
	magFilter=<gm_mapSpecularMaskMagFilter>;
	mipFilter=<gm_mapSpecularMaskMipFilter>;
	AddressU=<gm_mapSpecularMaskAddressU>;
	AddressV=<gm_mapSpecularMaskAddressV>;
	AddressW=<gm_mapSpecularMaskAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef REFLECTIONENABLED

float4 v4ReflectionColor;
float vReflectionLevel;

int gm_mapReflectionMaskMinFilter=2;
int gm_mapReflectionMaskMagFilter=2;
int gm_mapReflectionMaskMipFilter=2;
int gm_mapReflectionMaskAddressU=1;
int gm_mapReflectionMaskAddressV=1;
int gm_mapReflectionMaskAddressW=1;

texture mapReflectionMask;
sampler samplerReflectionMask = sampler_state {
	texture =<mapReflectionMask>;
	minFilter=<gm_mapReflectionMaskMinFilter>;
	magFilter=<gm_mapReflectionMaskMagFilter>;
	mipFilter=<gm_mapReflectionMaskMipFilter>;
	AddressU=<gm_mapReflectionMaskAddressU>;
	AddressV=<gm_mapReflectionMaskAddressV>;
	AddressW=<gm_mapReflectionMaskAddressW>;
};

texture mapReflectionFallOff;
sampler samplerReflectionFallOff = sampler_state {
	texture =<mapReflectionFallOff>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef ILLUMINATIONENABLED

float4 v4IlluminationColor;

int gm_mapIlluminationMinFilter=2;
int gm_mapIlluminationMagFilter=2;
int gm_mapIlluminationMipFilter=2;
int gm_mapIlluminationAddressU=1;
int gm_mapIlluminationAddressV=1;
int gm_mapIlluminationAddressW=1;

texture mapIllumination;
sampler samplerIllumination = sampler_state {
	texture =<mapIllumination>;
	minFilter=<gm_mapIlluminationMinFilter>;
	magFilter=<gm_mapIlluminationMagFilter>;
	mipFilter=<gm_mapIlluminationMipFilter>;
	AddressU=<gm_mapIlluminationAddressU>;
	AddressV=<gm_mapIlluminationAddressV>;
	AddressW=<gm_mapIlluminationAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef SCROLLENABLED

float4 gm_vScrollPosition;
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef REFLECTION2DENABLED

float4 gm_vReflection2DScale;
float4 gm_vReflection2DColor;

int gm_mapReflection2DMaskMinFilter=2;
int gm_mapReflection2DMaskMagFilter=2;
int gm_mapReflection2DMaskMipFilter=2;
int gm_mapReflection2DMaskAddressU=1;
int gm_mapReflection2DMaskAddressV=1;
int gm_mapReflection2DMaskAddressW=1;

texture gm_mapReflection2DMask;
sampler samplerReflection2DMask = sampler_state {
	texture =<gm_mapReflection2DMask>;
	minFilter=<gm_mapReflection2DMaskMinFilter>;
	magFilter=<gm_mapReflection2DMaskMagFilter>;
	mipFilter=<gm_mapReflection2DMaskMipFilter>;
	AddressU=<gm_mapReflection2DMaskAddressU>;
	AddressV=<gm_mapReflection2DMaskAddressV>;
	AddressW=<gm_mapReflection2DMaskAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef REFRACTION2DENABLED

float4 gm_vRefraction2DScale;
float4 gm_vRefraction2DColor;

int gm_mapRefraction2DMaskMinFilter=2;
int gm_mapRefraction2DMaskMagFilter=2;
int gm_mapRefraction2DMaskMipFilter=2;
int gm_mapRefraction2DMaskAddressU=1;
int gm_mapRefraction2DMaskAddressV=1;
int gm_mapRefraction2DMaskAddressW=1;

texture gm_mapRefraction2DMask;
sampler samplerRefraction2DMask = sampler_state {
	texture =<gm_mapRefraction2DMask>;
	minFilter=<gm_mapRefraction2DMaskMinFilter>;
	magFilter=<gm_mapRefraction2DMaskMagFilter>;
	mipFilter=<gm_mapRefraction2DMaskMipFilter>;
	AddressU=<gm_mapRefraction2DMaskAddressU>;
	AddressV=<gm_mapRefraction2DMaskAddressV>;
	AddressW=<gm_mapRefraction2DMaskAddressW>;
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
#if defined(REFLECTION2DENABLED) || defined(REFRACTION2DENABLED)

float4 gm_vFresnelMin;
float4 gm_vFresnelMax;
float gm_vFresnelPow;

float CalculateFresnelTerm(float fCosAngleEye) {
	return lerp(gm_vFresnelMin.x,gm_vFresnelMax.x,pow(1-fCosAngleEye,gm_vFresnelPow));
}

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
float4 v4SubSurfaceColor;
float fSubSurfaceTransparency;

int gm_mapTranslucencyMinFilter=2;
int gm_mapTranslucencyMagFilter=2;
int gm_mapTranslucencyMipFilter=2;
int gm_mapTranslucencyAddressU=1;
int gm_mapTranslucencyAddressV=1;
int gm_mapTranslucencyAddressW=1;

texture mapTranslucency;
sampler samplerTranslucency = sampler_state {
	texture =<mapTranslucency>;
	minFilter=<gm_mapTranslucencyMinFilter>;
	magFilter=<gm_mapTranslucencyMagFilter>;
	mipFilter=<gm_mapTranslucencyMipFilter>;
	AddressU=<gm_mapTranslucencyAddressU>;
	AddressV=<gm_mapTranslucencyAddressV>;
	AddressW=<gm_mapTranslucencyAddressW>;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
float4		v4RimLightColor;
float		fRimLightStrength;
float		fRimLightPower;

////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef ALPHAFADEENABLED

float4 gm_vAlphaFadeDistScaleOffset; // Scale1,Scale2,Offset1,Offset2
float4 gm_vAlphaFadeAngleScaleOffset; // Scale,Offset,Alpha1,Alpha2
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////



///
/// Internally defined input parameters
///
float4x4	m44ModelViewProj;		// Model * View * Projection matrix (not transposed)
float4x4	m44ModelView;			// Model * View
float4x4	m44View;				// View
float4x4	m44World;				// Model (world)
float4x4	m44ViewProj;			// View * Projection matrix
float4x4	m44Proj;				// Projection matrix  (not transposed)
float4x4	m44WorldViewProjScale;	// Projection matrix aligned to (0,0)-(1,1) (to sample from screen textures)
float4x4	m44ViewProjScale;		// Just as m44WorldViewProjScale except for the world transform
float4x4	m44WorldLight;			// World * LightView matrix
float4x4	m44WorldLight2;			// World * LightView matrix
float4x4	m44WorldLightClipProj;	// Light attenuation map matrix
float4x4	m44WorldShadow;			// World * Shadow
float4x4	m44WorldShadowProj;		// World * Shadow * Proj
float4x4	m44WorldShadowClip;		// World * ShadowClip
float4x4	m44WorldShadowLightProj;// World * Shadow * LightView * Proj
float3x4	m34ObjToCubeSpace;		// Object to Cube space matrix
float4		v4LightAttributes;		// x=Far, y=1/(Near-Far), z=Multiplier, w=1/Far
float4		v4LightPosObject;		// Light position in object space
float4		v4LightBoundsObject;	// x=Near/(Far-Near), y=1/(Far-Near)
float4		v4LightColor;			// Light color
float4		v4EyePosObject;			// Eye position object space
float4		v4EyePosWorld;			// Eye position world space
float		vEngineTime;			// Engine frame time (in seconds)
float4		v4Bones[26*3];			// Bones matrices used for matrix palette skinning
float4		v4BonesLights[7];		// Bones light sources (3 directional (dir,color) + 1 ambient term (color))
float4		v4BonesLights11[3];		// Bones light source (1 ambient term (color) and 1 directional (dir,color))
float		vTweenFactor;			// Tweening factor when doing vertex animation
float		vObjectReceiveShadow;	// Whether or not object receives shadow
float4		vFogSettings;			// x=Far, y=1/(Far-Near)
float4		vFogColor;				// Fog color
float2		gm_vZBiasOffset;		// Z Bias and offset
float4		v4WaterPatchSineWaves[4];	// WaterPatch SineWaves desc: fmt is: [ P A Q R] (formula H(x,z) = A * sin(P*x + Q.z + R);
float4		vStaticShadowColor;		// Shadow color for static shadows
float4		g_vDropShadowColor;		// Shadow color for drop shadows
float		g_vBoneShadowMultiplier=1; // Factor comes from Actors standing on static shadows

///
/// Internally defined texture maps
///
texture mapLightAttenuation;
sampler samplerLightAttenuation = sampler_state {
	texture =<mapLightAttenuation>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

texture mapCubeNormalizer;
sampler samplerCubeNormalizer = sampler_state {
	texture =<mapCubeNormalizer>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=WRAP;
	AddressV=WRAP;
	AddressW=WRAP;
};

texture mapEnvironment;
sampler samplerEnvironment = sampler_state {
	texture =<mapEnvironment>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=WRAP;
	AddressV=WRAP;
	AddressW=WRAP;
};

texture mapShadowColor;
sampler samplerShadowColor = sampler_state {
	texture =<mapShadowColor>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

texture mapShadowDropColor;
sampler samplerShadowDropColor = sampler_state {
	texture =<mapShadowDropColor>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

texture mapShadowColor2;
sampler samplerShadowColor2 = sampler_state {
	texture =<mapShadowColor2>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

texture mapReflection2D;
sampler samplerReflection2D = sampler_state {
	texture =<mapReflection2D>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

texture mapRefraction2D;
sampler samplerRefraction2D = sampler_state {
	texture =<mapRefraction2D>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};


texture mapStaticShadow1D;
sampler samplerStaticShadow1D = sampler_state {
	texture =<mapStaticShadow1D>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};


// Render states
#ifdef BLENDENABLED
int			BlendSrc=1;
int			BlendDst=1;
bool		AlphaTestEnabled=false;
int			AlphaTestValue=0;
#else
static		bool AlphaTestEnabled=false;
static		int AlphaTestValue=0;
#endif
int			ZBufferWrite=false;
int			Culling=2; // D3DCULL_CW
float4		v4Opacity;
float4		v4Bias;
int			FogEnabled;
int			gi_iWriteZBuffer;

//////////////////////////////////////////////////////////////////
// Math routines
//////////////////////////////////////////////////////////////////
///
/// Converts a signed value to an unsigned value
///
float tounsigned(float v) {
	return (v*0.5)+0.5;
}
float2 tounsigned(float2 v) {
	return (v*0.5)+0.5;
}
float3 tounsigned(float3 v) {
	return (v*0.5)+0.5;
}
float4 tounsigned(float4 v) {
	return (v*0.5)+0.5;
}

///
/// Converts an unsigned value to a signed value
///
float tosigned(float v) {
	return 2*(v-0.5);
}
float2 tosigned(float2 v) {
	return 2*(v-0.5);
}
float3 tosigned(float3 v) {
	return 2*(v-0.5);
}
float4 tosigned(float4 v) {
	return 2*(v-0.5);
}

///
/// Matrix palette skinning using internal defined bones
///
int4 CalcMatrixIndices(int4 vMatrixIndicesIn) {
	return vMatrixIndicesIn.zyxw*256; // To be used with D3DDECLTYPE_D3DCOLOR
}

float4 CalcWeights(float4 vWeightsIn) {
	//return vWeightsIn*256.0/255.0; // Weights as bytes
	//return vWeightsIn; // Weights as bytes
	return float4(vWeightsIn.x,vWeightsIn.y,vWeightsIn.z,1-dot(vWeightsIn.xyz,1)); // Weights as floats
}

float3 DoMPS(float3 vIn, int iBone, float w) {
	float3 vOut;
	float3x3 mn;
	mn[0]=v4Bones[iBone+0].xyz;
	mn[1]=v4Bones[iBone+1].xyz;
	mn[2]=v4Bones[iBone+2].xyz;
	return mul(mn,vIn)*w;
}
float3 DoMPS(float4 vIn, int iBone, float w) {
	float4 vOut;
	float3x4 mv;
	mv[0]=v4Bones[iBone+0];
	mv[1]=v4Bones[iBone+1];
	mv[2]=v4Bones[iBone+2];
	return mul(mv,vIn)*w;
}

float4 Do4MPS(float4 vIn, int4 iBones, float4 vWeights) {
	float4 vResult;
	vResult.xyz=DoMPS(vIn,iBones[0],vWeights[0]);
	vResult.xyz+=DoMPS(vIn,iBones[1],vWeights[1]);
	vResult.xyz+=DoMPS(vIn,iBones[2],vWeights[2]);
	vResult.xyz+=DoMPS(vIn,iBones[3],vWeights[3]);
	vResult.w=vIn.w;
	return vResult;
}

float3 Do4MPS(float3 vIn, int4 iBones, float4 vWeights) {
	float3 vResult;
	vResult=DoMPS(vIn,iBones[0],vWeights[0]);
	vResult+=DoMPS(vIn,iBones[1],vWeights[1]);
	vResult+=DoMPS(vIn,iBones[2],vWeights[2]);
	vResult+=DoMPS(vIn,iBones[3],vWeights[3]);
	return vResult;
}

float3 CalcBonesLight(float3 vNormal, float3 vDiffuse) {
	float3 vIntensity;
	vIntensity.x=dot(vNormal,v4BonesLights[0].xyz);
	vIntensity.y=dot(vNormal,v4BonesLights[2].xyz);
	vIntensity.z=dot(vNormal,v4BonesLights[4].xyz);
	vIntensity=max(vIntensity,0);
	float3 vResult;
	vResult=vIntensity.x*v4BonesLights[1].rgb;
	vResult+=vIntensity.y*v4BonesLights[3].rgb;
	vResult+=vIntensity.z*v4BonesLights[5].rgb;
	vResult+=v4BonesLights[6].rgb;
	vResult*=vDiffuse;
	return vResult;
}

float3 CalcBonesLight11(float3 vNormal, float3 vDiffuse) {
	float vIntensity;
	vIntensity=saturate(dot(vNormal,v4BonesLights11[1].xyz));
	float3 vResult;
	vResult=vIntensity*v4BonesLights11[2].rgb;
	vResult+=v4BonesLights11[0].rgb;
	vResult*=vDiffuse;	
	return vResult;
}


/*
void CalcPosition(out float4 vPositionOut, float4 vPositionIn)
{
	vPositionOut=mul(vPositionIn, m44ModelViewProj);
	//vPositionOut=mul(m44ModelViewProj, vPositionIn);
	//vPositionOut.z*=gm_vZBiasOffset.x; // Bias
	vPositionOut.zw-=gm_vZBiasOffset.y; // Offset
	//vPositionOut.xyz=float3(0,0,0);
}
*/

void CalcPosition(out float4 vPositionOut, float4 vPositionIn) 
{	
	//float4 pos = float4(vPositionIn.xyz*gm_vZBiasOffset.x, vPositionIn.w);
	//float4 c4 = m44ModelViewProj[3]*gm_vZBiasOffset.x + m44Proj[3] * (1-gm_vZBiasOffset.x);		
	//float4x4 mat = { m44ModelViewProj[0], m44ModelViewProj[1], m44ModelViewProj[2], c4 };
	//vPositionOut = mul(pos, mat);			
	//vPositionOut.zw-=gm_vZBiasOffset.y; 	
	vPositionOut = mul(vPositionIn, m44ModelViewProj);
	vPositionOut.zw-=gm_vZBiasOffset.y;	
}


void CalcTextureCoords(out float4 vTexCoordsOut, in float2 vTexCoordsIn) {
	vTexCoordsOut=vTexCoordsIn.xyxy;
#ifdef SCROLLENABLED
	vTexCoordsOut+=gm_vScrollPosition;
#endif
}

void CalcParallaxCoords(inout float4 vTexCoordsOut, in float2 vParallaxScale)
{
	vTexCoordsOut.zw=4.0/vParallaxScale.xy;
}

void CalculateTangentSpace(out float3x3 mTangentSpace, float3 vTangent, float3 vBinormal, float3 vNormal) {
	mTangentSpace=float3x3(vTangent.xyz,vBinormal.xyz,vNormal.xyz);
}

void CalcBonesLightHQ(out float3 vLightDir1Out, out float3 vLightDir2Out, out float3 vLightDir3Out, out float3 vHalfDir1Out, out float3 vHalfDir2Out, out float3 vHalfDir3Out, float3x3 m33TangentSpace, float3 vEyeDir) {
	vLightDir1Out=mul(m33TangentSpace,v4BonesLights[0].xyz);
	vLightDir2Out=mul(m33TangentSpace,v4BonesLights[2].xyz);
	vLightDir3Out=mul(m33TangentSpace,v4BonesLights[4].xyz);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDir));
	vHalfDir1Out=vLightDir1Out+vEyeDirTS;
	vHalfDir2Out=vLightDir2Out+vEyeDirTS;
	vHalfDir3Out=vLightDir3Out+vEyeDirTS;
}

void CalcBonesLightHQ11(out float3 vLightDir1Out,float3x3 m33TangentSpace, float3 vEyeDir) {
	vLightDir1Out=mul(m33TangentSpace,v4BonesLights11[1].xyz);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDir));
//	vHalfDir1Out=vLightDir1Out+vEyeDirTS;
}

///
/// Calculates the scaled light vector so that it will be a unit vector
/// at the lightsource far distance
///
float3 CalculateLightAttenutationVector(float3 vLightDirObject) {
	return v4LightAttributes.w*vLightDirObject.xyz;
}

///
void CalculateLightingVS(out float3 vLightDirTSOut, out float3 vHalfDirTSOut, out float3 vEyeDirTSOut, out float4 vLightDirScaledOSOut, out float4 vPositionLSOut, float4 vPosition, float3x3 m33TangentSpace) {

	// Calculate diffuse term
	float3 vLightDirObject=v4LightPosObject.xyz-vPosition.xyz;
	float3 v3EyeDirObject=v4EyePosObject.xyz-vPosition.xyz;
	float3 vLightDirTangentSpace=mul(m33TangentSpace,vLightDirObject);
	float3 vEyeDirTangentSpace=mul(m33TangentSpace,v3EyeDirObject);
	vLightDirTSOut=normalize(vLightDirTangentSpace.xyz);
	vEyeDirTSOut=normalize(vEyeDirTangentSpace.xyz);
	
	// Calculate specular term
#ifdef SPECULARENABLED
	// Output half angle vector for specular term
	vHalfDirTSOut=normalize(vEyeDirTangentSpace)+vLightDirTSOut;
#else
	vHalfDirTSOut=vLightDirTSOut; // Term not used - but binding currently needed from VS->PS
#endif

	// Output scaled light direction for attenuation
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	vPositionLSOut=mul(m44WorldLightClipProj,vPosition);
}

void CalculateLightingVS11(out float3 vLightDirTSOut, float4 vPosition, float3x3 m33TangentSpace) {
	// Calculate diffuse term
	float3 vLightDirObject=v4LightPosObject.xyz-vPosition.xyz;
	float3 v3EyeDirObject=v4EyePosObject.xyz-vPosition.xyz;
	float3 vLightDirTangentSpace=mul(m33TangentSpace,vLightDirObject);
	float3 vEyeDirTangentSpace=mul(m33TangentSpace,v3EyeDirObject);
	vLightDirTSOut=normalize(vLightDirTangentSpace.xyz);
}

// Distance attenuation is based on a g(x)=a+bx^2 function where g(x)=1 for x=n, g(x)=1 for x=f
float CalculateLightAttenuation(float4 vLightDirOS) {
	return saturate(vLightDirOS.w-dot(vLightDirOS.xyz,vLightDirOS.xyz));
}

float3 CalculateLightIntensity(float4 vLightClipOS, float4 vLightDirOS) {
	float3 vIntensity=tex2Dproj(samplerLightAttenuation,vLightClipOS).rgb; // Projector map
	vIntensity*=saturate(vLightClipOS).w; // Backfacing attenuation for spots)
	vIntensity*=CalculateLightAttenuation(vLightDirOS); // Distance attenuation
	vIntensity*=v4LightAttributes.z;
	return vIntensity;
}

void CalculateFog(out float vFogOut, float3 vPositionOS) {
	float fDistance=length(vPositionOS.xyz-v4EyePosObject.xyz);
	vFogOut=-fDistance*vFogSettings.y+vFogSettings.x; // compiles into a single mad instruction
	//vFogOut*=FogEnabled;
}

// note: vFog=0 means totally in fog, vFog=1 means no fog
float3 CalculateFogPS3(float3 vColor, float vFog) {
	return lerp(vColor,vFogColor,(1-vFog)*FogEnabled);
}

float CalculateLightDepth(float4 vPositionIn) {
	float fShadowDepth=mul(m44WorldShadow,vPositionIn).z;
	fShadowDepth=fShadowDepth*v4LightBoundsObject.y+v4LightBoundsObject.x;
	return fShadowDepth;
}

void CalculateShadowMapVS(out float fShadowDepth, float4 vPositionIn) {
	fShadowDepth=CalculateLightDepth(vPositionIn);
}
void CalculateShadowMapPS(out float4 vShadowColOut, float fShadowDepth) {
	//vShadowColOut=vPositionIn.z/vPositionIn.w;
	vShadowColOut=saturate(fShadowDepth);
}

void GetShadowMapVS(out float4 vPositionOut, out float fShadowDepth, float4 vPositionIn, float3 vNormalIn) {
	float3 vToLight=normalize(v4LightPosObject.xyz-vPositionIn.xyz);
	float fDepthBias=1.25;//max(max(fDistToLight-v4LightBoundsObject.w,0)*0.001,0.5);
	float fSlopeBias=(1-max(0,dot(vToLight,vNormalIn)))*0.5;
	vPositionIn.xyz+=vNormalIn*(fSlopeBias);
	vPositionIn.xyz+=vToLight*(fDepthBias);
	vPositionOut=mul(m44WorldShadowProj,vPositionIn);
	vPositionOut.x= vPositionOut.x*0.5+vPositionOut.w*0.5;
	vPositionOut.y=-vPositionOut.y*0.5+vPositionOut.w*0.5;
	fShadowDepth=CalculateLightDepth(vPositionIn);
	
	/*vPositionOut=mul(m44WorldShadowProj,vPositionIn);
	vPositionOut.x= vPositionOut.x*0.5+vPositionOut.w*0.5;
	vPositionOut.y=-vPositionOut.y*0.5+vPositionOut.w*0.5;
	float fDistToLight=length(vToLight);
	float4 vNewPos=vPositionIn;
	float fDepthBias=max(max(fDistToLight-v4LightBoundsObject.w,0)*0.001,0.5);
	vNewPos.xyz+=vNormalIn*(fSlopeBias);
	fShadowDepth=CalculateLightDepth(vNewPos);*/
}
float GetShadowMapPS(float4 vPositionIn, float fLightDepth) {
	float4 ShadowTexC=vPositionIn/vPositionIn.w;
	static const float fScale=0.002;
	static const float2 filterTaps[4]={
		{-0.66,-0.33},
		{-0.33, 0.66},
		{ 0.66, 0.33},
		{ 0.33,-0.66},
	};
	float4 sourcevals;
	sourcevals.x=(tex2D(samplerShadowColor,ShadowTexC+filterTaps[0]*fScale).r);
	sourcevals.y=(tex2D(samplerShadowColor,ShadowTexC+filterTaps[1]*fScale).r);
	sourcevals.z=(tex2D(samplerShadowColor,ShadowTexC+filterTaps[2]*fScale).r);
	sourcevals.w=(tex2D(samplerShadowColor,ShadowTexC+filterTaps[3]*fScale).r);
	sourcevals=sourcevals>fLightDepth;
	float vShadowAttenuation=dot(sourcevals,0.25);
	return vShadowAttenuation;
}

float GetShadowMapPS3(float4 vPositionIn, float fShadowDepth) {
	static const int NUM_BLUR_TAPS=8;
	static const float fScale=3.0;
	static const float4 filterTaps[NUM_BLUR_TAPS] = {
		{-0.000692, -0.000868, -0.002347, 0.000450},
		{0.000773, -0.002042, -0.001592, 0.001880},
		{-0.001208, -0.001198, -0.000425, -0.000915},
		{-0.000050, 0.000105, -0.000753, 0.001719},
		{-0.001855, -0.000004, 0.001140, -0.001212},
		{0.000684, 0.000273, 0.000177, 0.000647},
		{-0.001448, 0.002095, 0.000811, 0.000421},
		{0.000542, 0.001491, 0.000537, 0.002367},
	};
	float4 vPosLight=vPositionIn;
	float4 ShadowTexC=vPosLight/vPosLight.w;
	float fLightDepth=fShadowDepth;//-0.005;//*0.999-0.005;
	float fSum=0;
	for(int i=0; i<NUM_BLUR_TAPS/2; i++) {
		float4 fDepth;
		fDepth.x=tex2D(samplerShadowColor,ShadowTexC+filterTaps[i*2+0].xy*fScale).r;
		fDepth.y=tex2D(samplerShadowColor,ShadowTexC+filterTaps[i*2+0].zw*fScale).r;
		fDepth.z=tex2D(samplerShadowColor,ShadowTexC+filterTaps[i*2+1].xy*fScale).r;
		fDepth.w=tex2D(samplerShadowColor,ShadowTexC+filterTaps[i*2+1].zw*fScale).r;
		fDepth=fDepth>fLightDepth;
		fSum+=dot(fDepth,1);
	}
	float vShadowAttenuation=fSum/(NUM_BLUR_TAPS*2);
	return vObjectReceiveShadow<1?1:vShadowAttenuation;
}

void GetDropShadowMapVS(out float4 vPositionOut, out float4 vClipPositionOut, float4 vPositionIn) {
	vPositionOut=mul(m44WorldShadowProj,vPositionIn);
	vPositionOut.x= vPositionOut.x*0.5+vPositionOut.w*0.5;
	vPositionOut.y=-vPositionOut.y*0.5+vPositionOut.w*0.5;
	vClipPositionOut=mul(m44WorldShadowClip,vPositionIn);
}

float GetDropShadowMapPS(float4 vPositionIn, float4 vClipPositionIn) {
	float fIntensity=1-tex2Dproj(samplerShadowDropColor,vPositionIn).r;
	//fIntensity=fIntensity<1?1:0; // Boost intensity
	fIntensity=vClipPositionIn.z>0?fIntensity:0; // Back projection clipping
	return fIntensity;
}

void CalculateColorVS(out float4 vDiffuseOut, out float4 vSpecularOut, float4 vDiffuseIn) {
	// Output diffuse color
	vDiffuseOut.rgb=v4DiffuseColor.rgb*v4LightColor.rgb*vDiffuseIn.rgb;
#ifdef BLENDENABLED
	vDiffuseOut.a=vDiffuseIn.a*v4Opacity.a;
#else
	vDiffuseOut.a=1;
#endif
	// Output specular color
//#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
	vDiffuseOut.rgb*=g_vBoneShadowMultiplier;
//#endif
#ifdef SPECULARENABLED
	vSpecularOut=v4SpecularColor*v4LightColor;
//#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
	vSpecularOut*=g_vBoneShadowMultiplier;
//#endif
#else
	vSpecularOut=vDiffuseOut;
#endif
}

void CalculateColorVS11(out float4 vDiffuseOut, float4 vDiffuseIn) {
	// Output diffuse color
	vDiffuseOut.rgb=v4DiffuseColor.rgb*vDiffuseIn.rgb;
#ifdef BLENDENABLED
	vDiffuseOut.a=2*vDiffuseIn.a*v4Opacity.a;
#else
	vDiffuseOut.a=1;
#endif
}

void CalculateTexCoordsPS(out float2 vCoordsOut, float4 vCoordsIn, float3 vEyeDirIn) {
	vCoordsOut=vCoordsIn.xy;
#ifdef PARALLAXENABLED
	float3 vEyeDir=normalize(vEyeDirIn);
	float fBumpHeight=tex2D(samplerParallax,vCoordsIn).r;
	vCoordsOut+=vEyeDir.xy*(fBumpHeight*vParallaxScale-vParallaxBias)*vCoordsIn.zw;
#endif
}

float3 CalculateBumpNormalPS(float2 v2Coords) {
#ifdef BUMPENABLED
	float3 vNormal=tosigned(tex2D(samplerNormal,v2Coords).agb)*v4BumpScale;
	#ifdef BUMPDETAILENABLED
		float3 vDetailBump=tosigned(tex2D(samplerNormalDetail,v2Coords*vBumpDetailTileFactor).agb)*v4BumpDetailScale;
		vNormal+=vDetailBump;
	#endif
	vNormal.z=sqrt(1-dot(vNormal.xy,vNormal.xy));
	return vNormal;
#else
	return float3(0,0,1);
#endif
}

float3 CalculateBumpNormalPS11(float2 v2Coords) {
#ifdef BUMPENABLED
	float3 vNormal=tosigned(tex2D(samplerNormal,v2Coords).rgb)*v4BumpScale;
/*	#ifdef BUMPDETAILENABLED
		float3 vDetailBump=tosigned(tex2D(samplerNormalDetail,v2Coords*vBumpDetailTileFactor).rgb)*v4BumpDetailScale;
		vNormal+=vDetailBump;
	#endif
	vNormal.z=sqrt(1-dot(vNormal.xy,vNormal.xy));*/
	vNormal.z=1.0;
	return vNormal;
#else
	return float3(0,0,1);
#endif
}

//
// Returns 1 if not in shadow 0 if in shadow
float CalculateShadowPS(float fLightDist, float4 TexShadowCoords) {
	/*float fShadowDepth=tex2Dproj(samplerShadowColor,TexShadowCoords).r;
	float fLightIntensity=fShadowDepth>=fLightDist?1:0.5;
	return fLightIntensity;*/
	float fShadowDepth1=tex2Dproj(samplerShadowColor,TexShadowCoords).r;
	float fIntensity=fShadowDepth1>=fLightDist?1:0.5;
	return fIntensity;
	//return fFullInShadow;
	//return fIntensity1+fIntensity2;
	//return lerp(1,fLightIntensity,vObjectReceiveShadow);
}


float CalculateAlpha(float fAlphaIn) {
#ifdef BLENDENABLED
	return fAlphaIn;
#else
	return 1;
#endif
}

float CalculateAlphaFade(float3 vPosition, float3 vNormal) {
#ifdef ALPHAFADEENABLED
	float3 vAlphaTemp;
	// Distance face
	float3 vEye2VertexOS=v4EyePosObject.xyz-vPosition;
	float fLen=length(vEye2VertexOS);
	//float fLen=-vEye2VertexOS.z;
	vAlphaTemp.xy=fLen*gm_vAlphaFadeDistScaleOffset.xy+gm_vAlphaFadeDistScaleOffset.zw;
	// Angle fade
	vAlphaTemp.z=dot(vEye2VertexOS,vNormal)/fLen;
	// Clamp result
	vAlphaTemp=clamp(vAlphaTemp,0,1);
	float fAlphaDist=vAlphaTemp.x*vAlphaTemp.y;
	float fCosAngle=vAlphaTemp.z;
	float fAlphaAngle=fCosAngle*gm_vAlphaFadeAngleScaleOffset.x+gm_vAlphaFadeAngleScaleOffset.y;
	fAlphaAngle=clamp(fAlphaAngle,0,1);
	fAlphaAngle=lerp(gm_vAlphaFadeAngleScaleOffset.w,gm_vAlphaFadeAngleScaleOffset.z,fAlphaAngle);
	return fAlphaDist*fAlphaAngle;
#else
	return 1;
#endif
}

//////////////////////////////////////////////////////////////////
// Debugging aid
//////////////////////////////////////////////////////////////////
float vDebugDisableLighting;
float4 vDebugWireFrameColor;
#ifdef DEBUGENABLED
float3 CalculateDebugColor(float3 Color) {
	float3 NewColor=Color;
	NewColor=lerp(NewColor,0.5,vDebugDisableLighting); // Debugging
	NewColor=lerp(NewColor,vDebugWireFrameColor.rgb,vDebugWireFrameColor.a); // Debugging
	return NewColor;
}
float3 CalculateDebugColorPS(float3 Color, float3 Diffuse) {
	float3 NewColor=Color;
	NewColor=lerp(NewColor,Diffuse,vDebugDisableLighting); // Debugging
	NewColor=lerp(NewColor,vDebugWireFrameColor.rgb,vDebugWireFrameColor.a); // Debugging
	return NewColor;
}
#else
float3 CalculateDebugColor(float3 Color) {
	return Color;
}
float3 CalculateDebugColorPS(float3 Color, float3 Diffuse) {
	return Color;
}
#endif
