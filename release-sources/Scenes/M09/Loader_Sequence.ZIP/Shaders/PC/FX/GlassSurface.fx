#include "StandardCommon.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float4 vTexCoordsProj:	TEXCOORD1;
	float3 vLightDirTS:		TEXCOORD2;
	float3 vEyeDirTS:		TEXCOORD3;
	float3 vHalfDirTS:		TEXCOORD4;
	float4 Ambient:			TEXCOORD5;
	float vFog:				FOG;
};

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=mul(m33TangentSpace,vEyeDirOS);
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	//OUT.Diffuse.rgb=CalculateDebugColor(IN.v4Diffuse.rgb*v4DiffuseColor.rgb*fLightIntensity);
	//OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	OUT.Ambient=IN.v4Ambient;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a;
	float4 specular = float4(0,0,0,0);
#ifdef SPECULARENABLED
	specular = v4SpecularColor;
#endif
	OUT.Specular = specular;
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,IN.v4Position);
	
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
/*	// Ambient
	OUT.col.rgb=IN.Ambient.rgb*cTexel.rgb;
	
	// Diffuse
	float3 vLightDirTS=IN.vLightDirTS;
	OUT.col.rgb+=saturate(dot(vLightDirTS,v3BumpNormal))*IN.Diffuse.rgb*cTexel.rgb;*/
	
	OUT.col.rgb=0;
	
	// Specular
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	OUT.col.rgb+=v3SpecularColor;
#endif
	OUT.col.rgb*=2;
	
	float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	float fCosAngleEye=abs(dot(v3BumpNormal,vEyeDirTS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
	
	// @hs Optimize to be a tex2DProj(coords+offset*coords.w instead
	float2 vCoords=IN.vTexCoordsProj.xy/IN.vTexCoordsProj.w;
	
	float4 cReflect;
#ifdef REFLECTION2DENABLED
	float2 vReflectOffset=v3BumpNormal*gm_vReflection2DScale;
	cReflect=tex2D(samplerReflection2D,vCoords+vReflectOffset)*gm_vReflection2DColor;
	cReflect*=tex2D(samplerReflection2DMask,vTexCoords);
#endif
	
#ifdef REFRACTION2DENABLED
	float4 cRefract,cRefractOrig,cRefractDistort;
	float2 vRefractOffset=v3BumpNormal.xy*gm_vRefraction2DScale;
	cRefractDistort=tex2D(samplerRefraction2D,vCoords-vRefractOffset)*gm_vRefraction2DColor;
	cRefractOrig=tex2D(samplerRefraction2D,vCoords)*gm_vRefraction2DColor;
	if (cRefractDistort.a > 0.9)
		cRefract = cRefractDistort;
	else
		cRefract = cRefractOrig;
	//cRefract = cRefractDistort * cRefractDistort.a + cRefractOrig*(1-cRefractDistort.a);
#endif
	
#if defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)
	OUT.col.rgb+=lerp(cRefract,cReflect,fFresnel);
#elif defined(REFLECTION2DENABLED)
	OUT.col.rgb+=cReflect;
#elif defined(REFRACTION2DENABLED)
	OUT.col.rgb+=cRefract;
#endif
	
	OUT.col.a=1;
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////////////////

#define REFLECTION_RENDERSTATES \
	AlphaBlendEnable=true; \
	SrcBlend=One; \
	DestBlend=One; \
	CullMode=<Culling>; \
	ZFunc=Equal; \
	FogEnable=<FogEnabled>; \
	FogColor=float4(0,0,0,1) \
		
struct v2fStandardReflection 
{
	float4 Position:		POSITION;
	float4 Reflection:		COLOR0;
	float3 vTexCoords0:		TEXCOORD0;
	float2 vTexCoords1:		TEXCOORD1;
	float vFog:				FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardReflection Reflection_VS10(a2vStandard IN) {

	v2fStandardReflection OUT;
	
	float4 v4Position = IN.v4Position;
	float3 v3Normal = tosigned(IN.v3Normal);

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,v4Position);
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),v3Normal);
	
	// Create matrix to transform from tangent space to cube space
//	float3x3 m33ObjToCubeSpace;
//	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
//	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
//	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	
//	OUT.vTexCoordsCube=2*dot(eyedir,v3Normal)*v3Normal-eyedir;		//reflected vector for cubemap lookup
//	OUT.vTexCoordsCube=mul(m33ObjToCubeSpace,OUT.vTexCoordsCube);	//transform
	
	//move vTexCoords over
	OUT.vTexCoords1=OUT.vTexCoords0;
	
	// Generate fresnel term
	float3 eyedir = normalize(v4EyePosObject.xyz-v4Position.xyz);	//objectspace eyedir
	float3 vEyeDirTS=mul(m33TangentSpace,eyedir);	//transform into TS
	float fCosAngleEye=abs(dot(float3(0.0,1.0,0.0),vEyeDirTS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
	OUT.Reflection=fFresnel;
	return OUT;
}

technique GlassSurfaceAmbient_FFP < string Identifier="Ambient"; string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 Reflection_VS10();
		PixelShader=NULL;//compile ps_2_0 Reflection_PS20();
		
		Sampler[0]=<samplerReflection2D>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerRefraction2D>;
		ColorOp[1]=LERP;
		ColorArg0[1]=DIFFUSE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		ColorOp[2]=DISABLE;
		
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG1;
		AlphaArg0[1]=CURRENT|COMPLEMENT;	//one
		AlphaArg1[1]=DIFFUSE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fGlassRefractionMask {
	float4 Position:		POSITION;
};
v2fGlassRefractionMask GlassRefractionMask_VS20(a2vStandardHQ IN)
{
	v2fGlassRefractionMask OUT;
	CalcPosition(OUT.Position, IN.v4Position);
	return OUT;
}
f2sStandard GlassRefractionMask_PS20(v2fGlassRefractionMask IN) 
{
	f2sStandard OUT;
	OUT.col.rgb = float3(0,0,0);
	OUT.col.a=1;
	return OUT;
}
technique GlassRefractionMaskHQ_VS20_PS20 < string Identifier="RefractionMask"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 GlassRefractionMask_VS20();
		PixelShader=compile ps_2_0 GlassRefractionMask_PS20();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}

technique GlassRefractionMaskFFP < string Identifier="RefractionMask"; string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 GlassRefractionMask_VS20();
		PixelShader=NULL;
		
		ColorOp[0]=SUBTRACT;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;		
		
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}
