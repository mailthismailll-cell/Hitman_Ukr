#include "StandardCommon.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

#ifndef BLENDENABLED
struct v2fStandardZFillHQ11 {
	float4 Position:		POSITION;
};

f2sStandard ZFillHQ_PS11(v2fStandardZFillHQ11 IN) 
{
	f2sStandard OUT;
	OUT.col=1;
	return OUT;
}

v2fStandardZFillHQ11 ZFillHQ_VS11(a2vStandardHQ IN)
{
	v2fStandardZFillHQ11 OUT;
	
	float4 OPOS = IN.v4Position;
	float3 ONOR = IN.v3Normal;

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	OPOS.xyz += fWobblePosAmplitude * IN.v3Normal * fWobble;
	ONOR.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,OPOS);
	
	return OUT;
}

technique ZFillHQ_VS11_PS11 < string Identifier="ZFill"; > {
	pass p0 {
		VertexShader=compile vs_1_1 ZFillHQ_VS11();
		PixelShader=compile ps_1_1 ZFillHQ_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=false;
	}
}
#endif

#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct a2vAmbient11 {
	float4	v4Position:		POSITION;
	float4	vVertexCol:		COLOR0;
	float4	v4Ambient:		COLOR1;
	float2	vTexCoords:		TEXCOORD0;
};

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Ambient:			COLOR1;
	float2 vTexCoords0:		TEXCOORD0;
	float vFog:				FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

v2fStandardAmbient10 Ambient_VS11(a2vAmbient11 IN)
{
	v2fStandardAmbient10 OUT;
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateColorVS11(OUT.Diffuse,IN.vVertexCol);
	OUT.vTexCoords0=IN.vTexCoords;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	OUT.Ambient=(IN.v4Ambient*v4DiffuseColor)/2;
	return OUT;
}

f2sStandard Ambient_PS11(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;
	float4 cTexel=tex2D(samplerDiffuse,IN.vTexCoords0.xy);	
	// Ambient
	OUT.col.rgb=IN.Ambient.rgb*cTexel.rgb;
	// Diffuse
	OUT.col.rgb+=IN.Diffuse.rgb*cTexel.rgb;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

technique Ambient_VS11_PS11 < string Identifier="Ambient"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif
		TEXTURETRANSFORMFLAGS[0] = 0;
		TEXTURETRANSFORMFLAGS[1] = 0;
		TEXTURETRANSFORMFLAGS[2] = 0;
		TEXTURETRANSFORMFLAGS[3] = 0;
	}
}
#endif	//defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
struct v2fStandardAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords0:		TEXCOORD0;
//	float2 vTexCoords1:		TEXCOORD1;
	float vFog:				FOG;
};

f2sStandard AmbientHQ_MPS_PS(v2fStandardAmbientMPSHQ IN) 
{
	f2sStandard OUT;
	float4 cTexel=tex2D(samplerDiffuse,IN.vTexCoords0);
	float v3BumpNormal=float3(0,0,1);
	OUT.col.rgb =v4BonesLights11[2].rgb*saturate(dot(v4BonesLights11[1].rgb,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights11[0].rgb;	//ambient
	OUT.col.rgb*=IN.Diffuse.rgb*cTexel.rgb*v4DiffuseColor*2;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	
	return OUT;
}
#endif	//defined(MESH_WEIGHTED) || defined(MESH_RIGID)

#if defined(MESH_RIGID)
v2fStandardAmbientMPSHQ AmbientHQ_Rigid_VS(a2vStandardRigid IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
//	float3x3 m33TangentSpace;
//	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));	
//	CalcBonesLightHQ11(OUT.vLightDir1TS,m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.Diffuse.rgb=IN.vVertexCol.rgb;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);

//	OUT.vTexCoords1=OUT.vTexCoords0;
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);	
	return OUT;
}

technique AmbientHQ_Rigid < string Identifier="AmbientRigid"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_Rigid_VS();
		PixelShader=compile ps_1_1 AmbientHQ_MPS_PS();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif

		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;	
	}
}
#endif	//MESH_RIGID

#if defined(MESH_WEIGHTED)
v2fStandardAmbientMPSHQ AmbientHQ_MPS_VS(a2vStandardMPS IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
//	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
//	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
//	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
		
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
//	float3x3 m33TangentSpace;
//	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
//	CalcBonesLightHQ11(OUT.vLightDir1TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
//	OUT.vEyeDirTS=mul(m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
#ifdef BLENDENABLED
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
#else
	OUT.Diffuse.a=1;
#endif
//	CalculateColorVS11(OUT.Diffuse, IN.v4Diffuse);
//	OUT.Diffuse*=0.5f;
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);
//	OUT.vTexCoords1=OUT.vTexCoords0;
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	return OUT;
}

technique AmbientHQ_MPS < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_MPS_VS();
		PixelShader=compile ps_1_1 AmbientHQ_MPS_PS();
	
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif

		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;		
	}
}
#endif	//MESH_WEIGHTED

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#if MESH_STANDARD || MESH_TWEENED || MESH_RIGID

struct a2vStandardShadowMap 
{
	float4 v4Position	:	POSITION;
	float4 vTexCoords	:	TEXCOORD;
};

struct v2fStandardShadowMap 
{
	float4 Position		:	POSITION;
	float4 vTexCoords	:	TEXCOORD0;
};

v2fStandardShadowMap ShadowMap_VS(a2vStandardShadowMap IN) 
{
	v2fStandardShadowMap OUT;
	OUT.Position=mul((float4x4)m44WorldShadowProj,IN.v4Position);
	OUT.vTexCoords=IN.vTexCoords;
	return OUT;
}

#endif

#if MESH_STANDARD || MESH_TWEENED || MESH_RIGID

technique ShadowMap < string Identifier="ShadowMap"; string Performance="Fastest"; > {
	pass ShadowMapPass {
		VertexShader=compile vs_1_1 ShadowMap_VS();
		PixelShader = asm {	//<ShadowMap_PS>;
			ps.1.1
			def c0,0,0,0,0			
			tex		t0		;projected	
			mov		r0.rgb,	c0
			+ mov	r0.a,	t0_bias.a
		};
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED | D3DTTFF_COUNT3
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;			
	}
}
#endif

#if defined(MESH_RIGID)

technique ShadowMapRigid < string Identifier="ShadowMapRigid"; string Performance="Fastest"; > {
	pass ShadowMapRigid_p0 {
		VertexShader=compile vs_1_1 ShadowMap_VS();
		PixelShader = asm {	//<ShadowMap_PS>;
			ps.1.1
			def c0,0,0,0,0			
			tex		t0		;projected	
			mov		r0.rgb,	c0
			+ mov	r0.a,	t0_bias.a
		};
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

#if MESH_WEIGHTED

struct a2vStandardMPS11 {
	float4	v4Position:	POSITION;
	float4	v4Weights:	BLENDWEIGHT;
	int4	v4Indices:	BLENDINDICES;
	float4	vTexCoords:	TEXCOORD0;
};

struct v2fStandardShadowMap 
{
	float4 Position		:	POSITION;
	float4 vTexCoords	:	TEXCOORD0;
};
	
v2fStandardShadowMap ShadowMapMPS_VS(a2vStandardMPS11 IN) 
{
	v2fStandardShadowMap OUT;
	OUT.vTexCoords=IN.vTexCoords;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	OUT.Position=mul((float4x4)m44WorldShadowProj,v4PositionOut);
	return OUT;
}

technique ShadowMapMPS < string Identifier="ShadowMapMPS"; string Performance="Fastest"; > {
	pass ShadowMapMPSPass {
		VertexShader = compile vs_1_1 ShadowMapMPS_VS();
		PixelShader = asm {	//<ShadowMap_PS>;
			ps.1.1
			def c0,0,0,0,0
			tex t0			;projected					
			mov		r0.rgb, c0
			+ mov	r0.a,	t0_bias.a
		};
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;		
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#if MESH_STANDARD || MESH_TWEENED || MESH_RIGID

struct a2vStandardShadowDrop 
{
	float4	v4Position		:	Position;
	float3  v3Normal		:	Normal;
};

struct v2fStandardShadowDrop 
{
	float4	Position		:	POSITION;
	float4	TexLightDir2	:	COLOR0;
	float4	Diffuse			:	COLOR1;
	float4	vShadowCoords	:	TEXCOORD0;
	float4	TexLightClip	:	TEXCOORD1;
	float4	Clipping		:	TEXCOORD2;
	float4	ShadowClip		:	TEXCOORD3;
	float	vFog			:	FOG;
};

void GetDropShadowMapVS11(out float4 vPositionOut, out float4 vClipPositionOut, float4 vPositionIn) {
	vPositionOut=mul((float4x4)m44WorldShadowLightProj,vPositionIn);
	vClipPositionOut=mul((float4x4)m44WorldShadowClip,vPositionIn);
}

v2fStandardShadowDrop ShadowDrop_VS(a2vStandardShadowDrop IN) 
{ 
	v2fStandardShadowDrop OUT;
	//IN.v4Position = ScalePosition(IN.v4Position);
	CalcPosition(OUT.Position,IN.v4Position);

	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-IN.v4Position.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul(m44WorldLightClipProj,IN.v4Position);
	OUT.TexLightClip=vPositionLSOut;
	//OUT.TexLightDir2=tounsigned(vLightDirScaledOSOut/4);
	OUT.TexLightDir2=vLightDirScaledOSOut/4;
	OUT.Diffuse=1-g_vDropShadowColor;
	OUT.Diffuse*=g_vDropShadowColor.a;
	// Calculate angular fade
	float3 vLightDirOS=normalize(v4LightPosObject.xyz-IN.v4Position.xyz);
	float fDot=max(dot(tosigned(IN.v3Normal),vLightDirOS),0);
	OUT.Diffuse*=fDot;
	float4 vShadowClip;
	GetDropShadowMapVS11(OUT.vShadowCoords,vShadowClip,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	OUT.Clipping.x=tounsigned(OUT.TexLightClip.w);
	OUT.Clipping.y=1; //vShadowClip.z;
	OUT.Clipping.zw=1;
	OUT.ShadowClip.x=vShadowClip.z;
	OUT.ShadowClip.yzw=1;
	return OUT;
}

technique ShadowDrop < string Identifier="ShadowDrop"; string Performance="Fastest"; > {
	pass ShadowDropPass {
		VertexShader = compile vs_1_1 ShadowDrop_VS();
		PixelShader = asm { //ShadowDrop_PS
			ps.1.1

			// c0 is v4LightAttributes
			// c1 is vObjectReceiveShadow
			def c2,0.0,0.0,0.0,0.0	

			;v0												//TexLightDir2
			;v1												//IN.Diffuse
			tex t0				; projected texture lookup	//vShadowCoords
			tex t1				; projected texture lookup	//TexLightClip		float3 vIntensity=tex2Dproj(samplerLightAttenuation,vLightClipOS).rgb; // Projector map
			texcoord t2			; x=TexLightClip.w
			texkill t3			; y=vShadowClip.z

			dp3_x4	r1.rgb,			v0_bx2,	v0_bx2				;dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz)
			+mov	t2.a,			t2_bx2.a
			
//			xmma	t0.rgb,t1.rgb,discard.rgb,	t0.rgb,t2.a,	t1.rgb,v1.rgb	
//			xmma	d0,d1,d2, s0,s1,s2,s3
//			d0=s0*s1, d1=s2*s3, d2=s0*s1 + s2*s3		
			mul t0.rgb, t0,	t2.a
			mul t1.rgb, t1,	v1.a
						
			+add_x4_sat	r1.a,		v0.a,	-r1.b				;saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			mul			t1.rgb,		t1,		c1.a				;*vObjectReceiveShadow.a
			+mul_sat	r1.a,		r1.a,	c0.z				;*v4LightAttributes.z
			mul			t1.rgb,		t1,		r1.a	
			
//			final color = s0*s1 + (1-s0)*s2 + s3
//			final alpha = s6.b
//			final combiner prod register = s4*s5
//			xfc s0, s1, s2, s3, s4, s5, s6
		#if FOGENABLED
//			xfc		1-fog.a, fog.rgb, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,		t1
			mad			r0,			1-fog.a, fog.rgb, r0
			+ mov		r0.a,		c1
		#else
//			xfc		zero, zero, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,		t1
			+ mov		r0.a,		c2
		#endif

			//float fLightDepth=vPositionIn.z/vPositionIn.w;
			//fLightDepth=fLightDepth*0.999-0.005;
			//float fShadowDepth=tex2Dproj(samplerShadowColor,vPositionIn).r;
			//float fIntensity=fShadowDepth>=fLightDepth?1:0;
			//fIntensity=vObjectReceiveShadow<0.5?1:fIntensity;
			//float3 vLightAttenuation=tex2Dproj(samplerLightAttenuation,IN.TexLightClip).rgb; // Projector map
			//texkill t2 : vLightAttenuation*=saturate(IN.TexLightClip).w; // Backfacing attenuation for spots)
			// Distance attenuation is based on a g(x)=a+bx^2 function where g(x)=1 for x=n, g(x)=1 for x=f
			//vLightAttenuation*=saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			//vLightAttenuation*=v4LightAttributes.z;
			//vShadowAttenuation=1-tex2Dproj(samplerShadowDropColor,IN.vShadowCoords).r;
			//texkill t2 : vShadowAttenuation=IN.vShadowClip.z>0?vShadowAttenuation:0; // Back projection clipping
			//OUT.col=vShadowAttenuation*vLightAttenuation*IN.Diffuse;
		};
		
		AlphaBlendEnable=true;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		BlendOp=Max;
		CullMode=<Culling>;
		ZFunc=Equal;
		SpecularEnable=false;
//		ShadowFunc=Greater;
		
		PixelShaderConstant[0]= <v4LightAttributes>;
		PixelShaderConstant[1]= <vObjectReceiveShadow>;
		//PixelShaderConstant[2]= <zero>;	//reserved - defined diretly in the asm shader
	
		TEXTURETRANSFORMFLAGS[0] = 0 ;//256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;

		Texture[0] = <mapShadowDropColor>;
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=BORDER;
		AddressV[0]=BORDER;
		AddressW[0]=BORDER;
		BorderColor[0]=0;

		Texture[1] = <mapLightAttenuation>;
		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=CLAMP;
		AddressV[1]=CLAMP;
		AddressW[1]=CLAMP;

		minFilter[2]=LINEAR;
		magFilter[2]=LINEAR;
		mipFilter[2]=LINEAR;
		AddressU[2]=CLAMP;
		AddressV[2]=CLAMP;
		AddressW[2]=CLAMP;

		minFilter[3]=LINEAR;
		magFilter[3]=LINEAR;
		mipFilter[3]=LINEAR;
		AddressU[3]=CLAMP;
		AddressV[3]=CLAMP;
		AddressW[3]=CLAMP;
	}
}
#endif

#if defined(MESH_RIGID)

struct v2fStandardShadowDrop11 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float  vLightClipOS_sat:	COLOR1;
	float4 TexLightDir2:		TEXCOORD0;
	float4 vShadowCoords:		TEXCOORD1;
	float4 TexLightClip:		TEXCOORD2;
	float4 vShadowClip:			TEXCOORD3;
	float  vFog:				FOG;
};

v2fStandardShadowDrop11 ShadowDropRigid_VS(a2vStandardRigid IN) {
	v2fStandardShadowDrop11 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-IN.v4Position.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul(m44WorldLightClipProj,IN.v4Position);
	OUT.TexLightClip=vPositionLSOut;
	OUT.TexLightDir2=vLightDirScaledOSOut;
	OUT.Diffuse=1-g_vDropShadowColor;
	OUT.Diffuse*=g_vDropShadowColor.a;
	// Calculate angular fade
	float3 vLightDirOS=normalize(v4LightPosObject.xyz-IN.v4Position.xyz);
	float fDot=max(dot(tosigned(IN.v3Normal),vLightDirOS),0);
	OUT.Diffuse*=fDot;
	GetDropShadowMapVS11(OUT.vShadowCoords,OUT.vShadowClip,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	OUT.vLightClipOS_sat=saturate(OUT.TexLightClip).z;

	return OUT;
}
	
technique ShadowDrop < string Identifier="ShadowDropRigid"; string Performance="Fastest"; > {
	pass ShadowDropRigid_p0 {
		VertexShader = compile vs_1_1 ShadowDropRigid_VS();
		PixelShader = asm { //ShadowDrop_PS
			ps.1.1

			// c0 is v4LightAttributes
			// c1 is vObjectReceiveShadow
			def c2,0.0,0.0,0.0,0.0	

			;v0												//TexLightDir2
			;v1												//IN.Diffuse
			tex t0				; projected texture lookup	//vShadowCoords
			tex t1				; projected texture lookup	//TexLightClip		float3 vIntensity=tex2Dproj(samplerLightAttenuation,vLightClipOS).rgb; // Projector map
			texcoord t2			; x=TexLightClip.w
			texkill t3			; y=vShadowClip.z

			dp3_x4	r1.rgb,			v0_bx2,	v0_bx2				;dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz)
			+mov	t2.a,			t2_bx2.a
			
//			xmma	t0.rgb,t1.rgb,discard.rgb,	t0.rgb,t2.a,	t1.rgb,v1.rgb	
//			xmma	d0,d1,d2, s0,s1,s2,s3
//			d0=s0*s1, d1=s2*s3, d2=s0*s1 + s2*s3		
			mul t0.rgb, t0,	t2.a
			mul t1.rgb, t1,	v1.a
						
			+add_x4_sat	r1.a,		v0.a,	-r1.b				;saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			mul			t1.rgb,		t1,		c1.a				;*vObjectReceiveShadow.a
			+mul_sat	r1.a,		r1.a,	c0.z				;*v4LightAttributes.z
			mul			t1.rgb,		t1,		r1.a	
			
//			final color = s0*s1 + (1-s0)*s2 + s3
//			final alpha = s6.b
//			final combiner prod register = s4*s5
//			xfc s0, s1, s2, s3, s4, s5, s6
		#if FOGENABLED
//			xfc		1-fog.a, fog.rgb, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,		t1
			mad			r0,			1-fog.a, fog.rgb, r0
			+ mov		r0.a,		c1
		#else
//			xfc		zero, zero, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,		t1
			+ mov		r0.a,		c1
		#endif

			//float fLightDepth=vPositionIn.z/vPositionIn.w;
			//fLightDepth=fLightDepth*0.999-0.005;
			//float fShadowDepth=tex2Dproj(samplerShadowColor,vPositionIn).r;
			//float fIntensity=fShadowDepth>=fLightDepth?1:0;
			//fIntensity=vObjectReceiveShadow<0.5?1:fIntensity;
			//float3 vLightAttenuation=tex2Dproj(samplerLightAttenuation,IN.TexLightClip).rgb; // Projector map
			//texkill t2 : vLightAttenuation*=saturate(IN.TexLightClip).w; // Backfacing attenuation for spots)
			// Distance attenuation is based on a g(x)=a+bx^2 function where g(x)=1 for x=n, g(x)=1 for x=f
			//vLightAttenuation*=saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			//vLightAttenuation*=v4LightAttributes.z;
			//vShadowAttenuation=1-tex2Dproj(samplerShadowDropColor,IN.vShadowCoords).r;
			//texkill t2 : vShadowAttenuation=IN.vShadowClip.z>0?vShadowAttenuation:0; // Back projection clipping
			//OUT.col=vShadowAttenuation*vLightAttenuation*IN.Diffuse;
		};

		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
		AlphaBlendEnable=true;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		BlendOp=Max;
		CullMode=<Culling>;
		ZFunc=Equal;
		SpecularEnable=false;
//		ShadowFunc=Greater;
	
		PixelShaderConstant[0]= <v4LightAttributes>;
		PixelShaderConstant[1]= <vObjectReceiveShadow>;

		Texture[0] = <mapShadowDropColor>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=BORDER;
		AddressV[0]=BORDER;
		AddressW[0]=BORDER;
		BorderColor[0]=0;

		Texture[1] = <mapLightAttenuation>;
		TEXTURETRANSFORMFLAGS[1] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=CLAMP;
		AddressV[1]=CLAMP;
		AddressW[1]=CLAMP;

		minFilter[2]=LINEAR;
		magFilter[2]=LINEAR;
		mipFilter[2]=LINEAR;
		AddressU[2]=CLAMP;
		AddressV[2]=CLAMP;
		AddressW[2]=CLAMP;

		minFilter[3]=LINEAR;
		magFilter[3]=LINEAR;
		mipFilter[3]=LINEAR;
		AddressU[3]=CLAMP;
		AddressV[3]=CLAMP;
		AddressW[3]=CLAMP;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif

#if MESH_WEIGHTED

struct a2vStandardShadowDropMPS
{
	float4 v4Position	: Position;
	float3 v3Normal		: Normal;
	int4 v4Indices		: BlendIndices0;
	float4 v4Weights	: BlendWeight0;
};
struct v2fStandardShadowDropMPS 
{
	float4	Position		:	POSITION;
	float4	TexLightDir2	:	COLOR0;
	float4	vShadowCoords	:	TEXCOORD0;
	float4	TexLightClip	:	TEXCOORD1;
	float4	Clipping		:	TEXCOORD2;
	float	vFog			:	FOG;
};

void GetShadowMapVS11(out float4 vPositionOut, float4 vPositionIn) {
	vPositionOut=mul((float4x4)m44WorldShadowLightProj,vPositionIn);
}

v2fStandardShadowDropMPS ShadowDrop_MPS(a2vStandardShadowDropMPS IN)
{
	v2fStandardShadowDropMPS OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	//float4 v4Position = ScalePosition(IN.v4Position);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(IN.v3Normal,i,w);
	
	OUT.Position=mul(v4PositionOut, (float4x4)m44ModelViewProj);
	GetShadowMapVS11(OUT.vShadowCoords,v4PositionOut);
	if(OUT.vShadowCoords.w<0) OUT.vShadowCoords.w=0;
	
	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-v4PositionOut.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul((float4x4)m44WorldLightClipProj,v4PositionOut);
	OUT.TexLightClip=vPositionLSOut;
	OUT.TexLightDir2=tounsigned(vLightDirScaledOSOut/4);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	OUT.Clipping.x=tounsigned(OUT.TexLightClip.w);
	OUT.Clipping.y=1; //v4ClipPos.w;
	OUT.Clipping.zw=1;
	return OUT;
}

technique ShadowDropMPS < string Identifier="ShadowDropMPS"; string Performance="Fastest"; > {
	pass ShadowDropMPSPass {
		VertexShader = compile vs_1_1 ShadowDrop_MPS();
		PixelShader = asm { //ShadowDrop_MPS_PS
			ps.1.1

			// c0 is v4LightAttributes
			// c1 is vObjectReceiveShadow
			def c5, 0.0, 0.0, 0.0, 0.0 

			;v0												//TexLightDir2
			tex t0				; projected texture lookup	//vShadowCoords
			tex t1				; projected texture lookup	//TexLightClip		float3 vIntensity=tex2Dproj(samplerLightAttenuation,vLightClipOS).rgb; // Projector map
			texcoord t2			; x=TexLightClip.w y=vShadowClip.z
			
			dp3_x4		r1.rgb,		v0_bx2,		v0_bx2		;dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz)
			+mov		t2.a,		t2_bx2.a
			add_x4_sat	r1.a,		v0.a,		-r1.b		;saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			mul			t1.rgb,		t1,			c1.a		;*vObjectReceiveShadow.a
			+mul_d2_sat	r1.a,		r1.a,		c0.z		;*v4LightAttributes.z
			
//			xmma	t0.rgb,t1.rgb,discard.rgb,	1-t0.rgb,t2.a,		t1.rgb,v0_sat.a					
			mul			t0.rgb,		1-t0,		t2.a
			mul			t1.rgb,		t1,			r1.a

		#if FOGENABLED
//			xfc		1-fog.a, fog.rgb, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,			t1
			+ mov		r0.a,		c5
			mad			r0,			1-fog.a,	fog.rgb, r0
		#else
//			xfc		zero, zero, prod.rgb, zero, t0.rgb, t1.rgb, zero
			mul			r0.rgb,		t0,			t1
			+ mov		r0.a,		c5
		#endif

			//float fLightDepth=vPositionIn.z/vPositionIn.w;
			//fLightDepth=fLightDepth*0.999-0.005;
			//float fShadowDepth=tex2Dproj(samplerShadowColor,vPositionIn).r;
			//float fIntensity=fShadowDepth>=fLightDepth?1:0;
			//float fIntensity=fLightDepth>fShadowDepth?0:1;
			//fIntensity=vObjectReceiveShadow<0.5?1:fIntensity;
			//float3 vLightAttenuation=tex2Dproj(samplerLightAttenuation,IN.TexLightClip).rgb; // Projector map
			//texkill t2 : vLightAttenuation*=saturate(IN.TexLightClip).w; // Backfacing attenuation for spots)
			// Distance attenuation is based on a g(x)=a+bx^2 function where g(x)=1 for x=n, g(x)=1 for x=f
			//vLightAttenuation*=saturate(IN.TexLightDir2.w-dot(IN.TexLightDir2.xyz,IN.TexLightDir2.xyz));
			//vLightAttenuation*=v4LightAttributes.z;
			//vShadowAttenuation=1-tex2Dproj(samplerShadowDropColor,IN.vShadowCoords).r;
			//texkill t2 : vShadowAttenuation=IN.vShadowClip.z>0?vShadowAttenuation:0; // Back projection clipping
			//OUT.col=vShadowAttenuation*vLightAttenuation*IN.Diffuse;
		};
		
		AlphaBlendEnable=true;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		BlendOp=Add;
		CullMode=<Culling>;
		ZFunc=Equal;
		ZWriteEnable=false;
		SpecularEnable=false;
//		ShadowFunc=Greater;
		
		PixelShaderConstant[0]= <v4LightAttributes>;
		PixelShaderConstant[1]= <vObjectReceiveShadow>;
	
		Texture[0] = <mapShadowColor>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		minFilter[0]=POINT; //LINEAR;
		magFilter[0]=POINT; //LINEAR;
		mipFilter[0]=POINT; //LINEAR;
		AddressU[0]=BORDER;
		AddressV[0]=BORDER;
		AddressW[0]=BORDER;
		BorderColor[0]=0xffffffff;

		Texture[1] = <mapLightAttenuation>;
		TEXTURETRANSFORMFLAGS[1] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=CLAMP;
		AddressV[1]=CLAMP;
		AddressW[1]=CLAMP;
		
		minFilter[2]=LINEAR;
		magFilter[2]=LINEAR;
		mipFilter[2]=LINEAR;
		AddressU[2]=CLAMP;
		AddressV[2]=CLAMP;
		AddressW[2]=CLAMP;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardLighting11 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 vTexCoords0:			TEXCOORD0;
	float4 vTexCoords1:			TEXCOORD1;
	float3 TexLightDir:			TEXCOORD2;
	float vFog:					FOG;
};

// Distance attenuation is based on a g(x)=a+bx^2 function where g(x)=1 for x=n, g(x)=1 for x=f
float CalculateLightAttenuation11(float4 vLightDirOS) {
	return saturate(vLightDirOS.w-dot(vLightDirOS.xyz,vLightDirOS.xyz));
}

float3 CalculateLightIntensity11(float3 vLightClipOS, float4 vLightDirOS) {
	float3 vIntensity=tex2D(samplerLightAttenuation,vLightClipOS).rgb; // Projector map
	
	//TODO: MOVE TO DIFFUSE CHANNEL AND ENABLE THE OUTCOMMENTED LINE
	//vIntensity*=saturate(vLightClipOS).w; // Backfacing attenuation for spots)
	
	vIntensity*=CalculateLightAttenuation11(vLightDirOS); // Distance attenuation
	vIntensity*=v4LightAttributes.z;
	return vIntensity;
}

f2sStandard Lighting_PS11(v2fStandardLighting11 IN) {
	f2sStandard OUT;
	
	// Read base stuff
	float4 cTexel=tex2D(samplerDiffuse,IN.vTexCoords0); 
	float3 v3BumpNormal=CalculateBumpNormalPS11(IN.vTexCoords1);

	// Diffuse
	float v1DiffuseIntensity=saturate(dot(v3BumpNormal.xyz,IN.TexLightDir.xyz));
	float3 v3DiffuseColor=v1DiffuseIntensity*IN.Diffuse.rgb*cTexel.rgb;
	float3 vResultColor=v3DiffuseColor;
	
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	OUT.col.rgb=vResultColor;
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardLighting11 Lighting_VS11(a2vStandardHQ IN) {
	v2fStandardLighting11 OUT;
	CalcPosition(OUT.Position,IN.v4Position);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS11(OUT.TexLightDir,IN.v4Position,m33TangentSpace);
	CalculateColorVS11(OUT.Diffuse,IN.vVertexCol);
	OUT.TexLightDir.xyz=normalize(OUT.TexLightDir.xyz);
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);
	OUT.vTexCoords1=OUT.vTexCoords0;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

technique Lighting_VS11_PS11 < string Identifier="Lighting"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Lighting_VS11();
		PixelShader=compile ps_1_1 Lighting_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardLighting11 LightingRigid_VS11(a2vStandardRigid IN) {
	v2fStandardLighting11 OUT;
	CalcPosition(OUT.Position,IN.v4Position);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS11(OUT.TexLightDir,IN.v4Position,m33TangentSpace);
	CalculateColorVS11(OUT.Diffuse,IN.vVertexCol);
	OUT.Diffuse.a*=CalculateAlphaFade(IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);
	OUT.vTexCoords1=OUT.vTexCoords0;
	return OUT;
}

technique LightingRigid_VS11_PS11 < string Identifier="LightingRigid"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 LightingRigid_VS11();
		PixelShader=compile ps_1_1 Lighting_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardLighting11 Lighting_MPS_VS11(a2vStandardMPS IN)
{
	v2fStandardLighting11 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS11(OUT.TexLightDir,v4PositionOut,m33TangentSpace);
	CalculateColorVS11(OUT.Diffuse,IN.v4Diffuse);
	CalcTextureCoords(OUT.vTexCoords0,IN.vTexCoords);
	OUT.vTexCoords1=OUT.vTexCoords0;
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	return OUT;
}

technique Lighting_MPS_VS11_PS11 < string Identifier="LightingMPS"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Lighting_MPS_VS11();
		PixelShader=compile ps_1_1 Lighting_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
	}
}
#endif
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#ifdef ILLUMINATIONENABLED

struct a2vStandardIlluminate11 {
	float4	v4Position:		POSITION;
	float4	vVertexCol:		COLOR0; // Original vertex color
	float2	vTexCoords:		TEXCOORD0;
};

struct v2fStandardIlluminate {
	float4 Position:			POSITION;
	float4 IlluminateColor:		COLOR0;
	float2 TexDiffuse1:			TEXCOORD0;
	float2 TexDiffuse2:			TEXCOORD1;
	float vFog:					FOG;
};

f2sStandard Illuminate_PS11(v2fStandardIlluminate IN) {
	f2sStandard OUT;
	float4 cBase=tex2D(samplerDiffuse,IN.TexDiffuse1);
	float4 cIllum=tex2D(samplerIllumination,IN.TexDiffuse2);
	OUT.col.rgb=cBase.rgb*cIllum.rgb*IN.IlluminateColor.rgb;
	OUT.col.a=CalculateAlpha(cBase.a*cIllum.a*IN.IlluminateColor.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardIlluminate Illuminate_VS11(a2vStandardIlluminate11 IN) {
	v2fStandardIlluminate OUT;

	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

technique Illuminate_VS11_PS11 < string Identifier="Illuminate"; string Performance="Fastest"; > {
	pass Illuminate_p0 {
		VertexShader=compile vs_1_1 Illuminate_VS11();
		PixelShader=compile ps_1_1 Illuminate_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardIlluminate IlluminateRigid_VS11(a2vStandardRigid IN) {
	v2fStandardIlluminate OUT;

	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

technique IlluminateRigid_VS11_PS11 < string Identifier="IlluminateRigid"; string Performance="Fastest"; > {
	pass IlluminateRigid_0 {
		VertexShader=compile vs_1_1 IlluminateRigid_VS11();
		PixelShader=compile ps_1_1 Illuminate_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=float4(0,0,0,1);
#endif
	}
}
#endif

#endif

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#ifdef REFLECTIONENABLED

struct a2vStandard_Refl_p1 {
	float4 v4Position	: POSITION;
	float2 v2Texture	: TEXCOORD;
	float4 v3Normal		: NORMAL;
};

struct a2vStandard_Refl_p2 {
	float4 v4Position	: POSITION;
	float4 vLightCol	: COLOR0;
	float3 vLightDir	: COLOR1;
//	float4 v4Ambient	: AMBIENTCOLOR; //move to vertexshaderconstant
	float2 v2Texture	: TEXCOORD0;
	float4 v3Tangent	: TANGENT;
	float4 v3Binormal	: BINORMAL;
	float4 v3Normal		: NORMAL;
};

struct v2fStandardReflection_Pass1 {
	float4 Position				: POSITION;
	float2 TexCoord				: TEXCOORD0;
	float2 vEyeDirTangentSpace	: TEXCOORD1;
	float vFog					: FOG;
};

struct v2fStandardReflection_Pass2 {
	float4 Position:			POSITION;
	float4 Reflection:			COLOR0;
#if BUMPENABLED
	float2 TexCoord:			TEXCOORD0;
#else
	float3 TexCoord:			TEXCOORD0;
#endif
	float4 TangentToCubeSpace0:	TEXCOORD1;
	float4 TangentToCubeSpace1:	TEXCOORD2;
	float4 TangentToCubeSpace2:	TEXCOORD3;
	float  vFog						: FOG;
};

v2fStandardReflection_Pass1 Reflection_VS_Pass1(a2vStandard_Refl_p1 IN) {
	v2fStandardReflection_Pass1 OUT;

	CalcPosition(OUT.Position,IN.v4Position);
	//OUT.TexCoord.xy=ScaleTexCoord(IN.v2Texture.xy);
	CalcTextureCoords(OUT.TexCoord.xy,IN.v2Texture.xy);

	float3 vEyeDir=normalize(v4EyePosObject.xyz-IN.v4Position.xyz);

	float3 vEyeDirTangentSpace=dot(IN.v3Normal,vEyeDir);
	float fRes=1-saturate(vEyeDirTangentSpace.z);
	OUT.vEyeDirTangentSpace.x=fRes;
	OUT.vEyeDirTangentSpace.y=fRes;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

v2fStandardReflection_Pass2 Reflection_VS_Pass2(a2vStandard_Refl_p2 IN) {
	v2fStandardReflection_Pass2 OUT;

	CalcPosition(OUT.Position,IN.v4Position);		

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,IN.v3Tangent,IN.v3Binormal,IN.v3Normal);
#if BUMPENABLED
	//OUT.TexCoord.xy=ScaleTexCoord(IN.v2Texture.xy);
	CalcTextureCoords(OUT.TexCoord.xy,IN.v2Texture.xy);
#else
	OUT.TexCoord.xyz=float3(0,0,1);
#endif

	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;

	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[0]);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[1]);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[2]);

	float3 vEyeDir=normalize(v4EyePosObject-IN.v4Position.xyz);
	float3 vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);

	OUT.TangentToCubeSpace0.w=vEyeDirCubeSpace.x;
	OUT.TangentToCubeSpace1.w=vEyeDirCubeSpace.y;
	OUT.TangentToCubeSpace2.w=vEyeDirCubeSpace.z;
	//OUT.Reflection=v4ReflectionColor;//*(max(dot(IN.v3Normal,IN.vLightDir),0)*IN.vLightCol+IN.v4Ambient);
	CalculateColorVS11(OUT.Reflection, IN.vLightCol);
	OUT.Reflection *= 0.5f * v4ReflectionColor;

	CalculateFog(OUT.vFog, IN.v4Position.xyz);
	return OUT;
}

technique Reflection_VS11_PS11 < string Identifier="Reflection"; string Performance="Fastest"; > {
	pass std_Reflection_p1 {
		VertexShader=compile vs_1_1 Reflection_VS_Pass1();

		PixelShader = asm {		//<Reflection_PS_Pass1>
			ps.1.1
			
			tex		t0
			tex		t1
			mul_x2	t0.rgb,t0,t1
			dp3		r0.rgba,t0,t0
		};
		
		texture[0] =<mapReflectionMask>;
		TEXTURETRANSFORMFLAGS[0] = 0;
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;
		texture[1] =<mapReflectionFallOff>;
		TEXTURETRANSFORMFLAGS[1] = 0;
		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=CLAMP;
		AddressV[1]=CLAMP;
		AddressW[1]=CLAMP;
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=One;
		DestBlend=Zero;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=Alpha;
		SpecularEnable=false;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}

	pass std_Reflection_p2 {
		VertexShader=compile vs_1_1 Reflection_VS_Pass2();
		
		PixelShader = asm {	//<Reflection_PS_Pass2>
			ps.1.1
			def c0,1,0,0,1
#if BUMPENABLED
			tex t0					; Define t0 as a standard 3-vector.
			texm3x3pad t1, t0		; Perform first row of matrix multiply.
			texm3x3pad t2, t0		; Perform second row of matrix multiply.
			texm3x3vspec t3, t0		; Perform third row of matrix multiply, sample texture 2, 
			; do reflection calculation using eye ray, and sample texture 3 specular map.
#else
			texcoord t0					; Define t0 as a standard 3-vector.
			texm3x3pad t1, t0			; Perform first row of matrix multiply.
			texm3x3pad t2, t0			; Perform second row of matrix multiply.
			texm3x3vspec t3, t0			; Perform third row of matrix multiply, sample texture 2,
			; do reflection calculation using eye ray, and sample texture 3 specular map.
#endif
			mul	r0.rgba, t3,v0      ; Put specular color into the result.

#if FOGENABLED
			mul r1, 1-fog.a, fog.rgb	; r0.rgb = 1-fog.a*fog.rgb + (1-1-fog.a)*r0
			mad r0, r0, fog.a, r1
#endif
		};
		
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif

		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
#if BUMPENABLED
		texture[0] =<mapNormal>;
		TEXTURETRANSFORMFLAGS[0]=0;
#endif
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;

		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=WRAP;
		AddressV[1]=WRAP;
		AddressW[1]=WRAP;

		minFilter[2]=LINEAR;
		magFilter[2]=LINEAR;
		mipFilter[2]=LINEAR;
		AddressU[2]=WRAP;
		AddressV[2]=WRAP;
		AddressW[2]=WRAP;

		texture[3] =<mapEnvironment>;
		TEXTURETRANSFORMFLAGS[3]=0;
		minFilter[3]=LINEAR;
		magFilter[3]=LINEAR;
		mipFilter[3]=LINEAR;
		AddressU[3]=WRAP;
		AddressV[3]=WRAP;
		AddressW[3]=WRAP;
		
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=DestAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=RED|GREEN|BLUE;
	}
}

#if defined(MESH_RIGID)
v2fStandardReflection_Pass2 ReflectionRigid_VS_Pass2(a2vStandard_Refl_p2 IN) {
	v2fStandardReflection_Pass2 OUT;

	CalcPosition(OUT.Position,IN.v4Position);		

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,IN.v3Tangent,IN.v3Binormal,IN.v3Normal);
#if BUMPENABLED
	//OUT.TexCoord.xy=ScaleTexCoord(IN.v2Texture.xy);
	CalcTextureCoords(OUT.TexCoord.xy,IN.v2Texture.xy);
#else
	OUT.TexCoord.xyz=float3(0,0,1);
#endif
	
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;

	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[0]);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[1]);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m33ObjToCubeSpace[2]);

	float3 vEyeDir=normalize(v4EyePosObject-IN.v4Position.xyz);
	float3 vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);

	OUT.TangentToCubeSpace0.w=vEyeDirCubeSpace.x;
	OUT.TangentToCubeSpace1.w=vEyeDirCubeSpace.y;
	OUT.TangentToCubeSpace2.w=vEyeDirCubeSpace.z;
	float4 v4Ambient = float4(0.1,0.1,0.1,0.1);
	OUT.Reflection=v4ReflectionColor*(max(dot(IN.v3Normal,IN.vLightDir),0)*IN.vLightCol+v4Ambient);	//move v4Ambient to constant set from C++ side
	CalculateFog(OUT.vFog, IN.v4Position);
	return OUT;
}

technique ReflectionRigid_VS11_PS11 < string Identifier="ReflectionRigid"; string Performance="Fastest"; > {
	pass std_Reflection_p1 {
		VertexShader=compile vs_1_1 Reflection_VS_Pass1();

		PixelShader = asm {		//<Reflection_PS_Pass1>
			ps.1.1
			
			tex		t0
			tex		t1
			mul_x2	t0,t0,t1
			dp3		r0,t0,t0
		};
		
		texture[0] =<mapReflectionMask>;
		TEXTURETRANSFORMFLAGS[0]=0;
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;
		texture[1] =<mapReflectionFallOff>;
		TEXTURETRANSFORMFLAGS[1]=0;
		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=CLAMP;
		AddressV[1]=CLAMP;
		AddressW[1]=CLAMP;
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=One;
		DestBlend=Zero;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=Alpha;
		SpecularEnable=false;
		FogEnable=false;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}	
	
	pass std_Reflection_p2 {
		VertexShader=compile vs_1_1 ReflectionRigid_VS_Pass2();
		
		PixelShader = asm {	//<Reflection_PS_Pass2>
			ps.1.1
			
#if BUMPENABLED
			tex t0						; Define t0 as a standard 3-vector.
			texm3x3pad t1, t0_bx2		; Perform first row of matrix multiply.
			texm3x3pad t2, t0_bx2		; Perform second row of matrix multiply.
			texm3x3vspec t3, t0_bx2		; Perform third row of matrix multiply, sample texture 2, 
			; do reflection calculation using eye ray, and sample texture 3 specular map.
#else
			texcoord t0					; Define t0 as a standard 3-vector.
			texm3x3pad t1, t0			; Perform first row of matrix multiply.
			texm3x3pad t2, t0			; Perform second row of matrix multiply.
			texm3x3vspec t3, t0			; Perform third row of matrix multiply, sample texture 2,
			; do reflection calculation using eye ray, and sample texture 3 specular map.
#endif
			mul	r0.rgba, t3,v0      ; Put specular color into the result.

#if FOGENABLED
			mul r1, 1-fog.a, fog.rgb	; r0.rgb = 1-fog.a*fog.rgb + (1-1-fog.a)*r0
			mad r0, r0, fog.a, r1
#endif
		};
	
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif

#if BUMPENABLED
		texture[0] =<mapNormal>;
		TEXTURETRANSFORMFLAGS[0]=0;
#endif
		minFilter[0]=LINEAR;
		magFilter[0]=LINEAR;
		mipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;

		minFilter[1]=LINEAR;
		magFilter[1]=LINEAR;
		mipFilter[1]=LINEAR;
		AddressU[1]=WRAP;
		AddressV[1]=WRAP;
		AddressW[1]=WRAP;
		TEXTURETRANSFORMFLAGS[1]=0;

		minFilter[2]=LINEAR;
		magFilter[2]=LINEAR;
		mipFilter[2]=LINEAR;
		AddressU[2]=WRAP;
		AddressV[2]=WRAP;
		AddressW[2]=WRAP;
		TEXTURETRANSFORMFLAGS[2]=0;

		texture[3] =<mapEnvironment>;
		TEXTURETRANSFORMFLAGS[3]=0;
		minFilter[3]=LINEAR;
		magFilter[3]=LINEAR;
		mipFilter[3]=LINEAR;
		AddressU[3]=WRAP;
		AddressV[3]=WRAP;
		AddressW[3]=WRAP;
		
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=DestAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable = <gi_iWriteZBuffer>;
		ColorWriteEnable=RED|GREEN|BLUE;
	}
}
#endif	//MESH_RIGID

#endif	//REFLECTIONENABLED

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
struct a2vStandardZPass {
	float4 v4Position	:	POSITION;
	float2 vTexCoords	:	TEXCOORD0;
	float4 vVertexCol	:	COLOR0;
};
struct v2fStandardZPass {
	float4 Position		:	POSITION;
	float4 Diffuse		:	COLOR0;
	float2 TexDiffuse	:	TEXCOORD0;
	float1 Fog			:	FOG;
};

f2sStandard ZPass_PS11(v2fStandardZPass IN) 
{
	f2sStandard OUT;
	
	float4 cTexel=tex2D(samplerDiffuse,IN.TexDiffuse.xy);
	OUT.col.rgb=2*IN.Diffuse.rgb*cTexel.rgb;
	OUT.col.a=CalculateAlpha(2*IN.Diffuse.a*cTexel.a);
	
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardZPass ZPass_VS11(a2vStandardZPass IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	OUT.Diffuse.rgb=float3(0,0,0);
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	CalculateFog(OUT.Fog,IN.v4Position.xyz);

	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPass"; > {
	pass p0 {
		VertexShader=compile vs_1_1 ZPass_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=true;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_RIGID)

v2fStandardZPass ZPassRigid_VS11(a2vStandardRigid IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	OUT.Diffuse.rgb=float3(0,0,0);
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	CalculateFog(OUT.Fog,IN.v4Position.xyz);

	return OUT;
}

technique ZPassRigid_VS11_PS11 < string Identifier="PostFilterZPassRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassRigid_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=true;
		FogColor=<vFogColor>;
	}
}
#endif

#ifdef MESH_WEIGHTED
v2fStandardZPass ZPassMPS_VS11(a2vStandardMPS IN)
{
	v2fStandardZPass OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);

	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexDiffuse=IN.vTexCoords;
	OUT.Diffuse.rgb=float3(0,0,0);
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	CalculateFog(OUT.Fog,v4PositionOut.xyz);
	
	return OUT;
}

technique ZPassMPS_VS11_PS11 < string Identifier="PostFilterZPassMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassMPS_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=true;
		FogColor=<vFogColor>;
	}
}
#endif
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
