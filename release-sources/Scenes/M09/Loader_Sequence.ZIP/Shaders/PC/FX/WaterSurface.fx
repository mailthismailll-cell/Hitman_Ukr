#include "StandardCommon.fx"

struct a2vWaterPatchHQ {
	float4	v4Position:	POSITION;
	float4  v4Dynamics:	NORMAL;
	float4	vLightCol:	COLOR0; // Light color * vertex color
	float4	vLightDir:	COLOR1; // Light direction
	float4	v4Ambient:	COLOR2; // Ambient color
	float4	vVertexCol:	COLOR3; // Original vertex color
	float2	vTexCoords:	TEXCOORD0;
	float3	v3Tangent:	TANGENT0;
	float3	v3Binormal:	BINORMAL0;
};

struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords1:		TEXCOORD0;
	float4 vTexCoords2:		TEXCOORD1;
	float4 vTexCoordsProj:	TEXCOORD2;
	float3 vLightDirTS:		TEXCOORD3;
	float3 vEyeDirTS:		TEXCOORD4;
	float3 vHalfDirTS:		TEXCOORD5;
	float4 Ambient:			TEXCOORD6;
	float vFog:				FOG;
};

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vWaterPatchHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float4  	sines, cosines;
	float3 		normal = IN.v4Dynamics.xyz;
	float3		tangent,binormal;
	float3x3 	m33TangentSpace;
	float2   	vParallaxScale;
	
	float4 worldPos=mul(m44World,IN.v4Position);
	float4 fSWArg = worldPos.x * v4WaterPatchSineWaves[0] + worldPos.z * v4WaterPatchSineWaves[1] + v4WaterPatchSineWaves[3];
	
	sincos(fSWArg, sines, cosines);
	
	// height = Ai*sin(Pi*x + Qi*z + Ri)
	
	worldPos.y += dot(v4WaterPatchSineWaves[2], sines);
	worldPos.y += IN.v4Dynamics.w;	// add the contribution from the ripples 
	
	// NOR = (-Ai pi cos (pi x + qi z + ri), 1 , -Ai qi cos (pi x + qi z + ri);
	normal.x -= dot(v4WaterPatchSineWaves[0] * v4WaterPatchSineWaves[2], cosines);
	normal.y = 1.f;
	normal.z -= dot(v4WaterPatchSineWaves[1] * v4WaterPatchSineWaves[2], cosines);

	CalculateTangentSpace(m33TangentSpace,IN.v3Tangent,IN.v3Binormal,normal);
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=normalize(mul(m33TangentSpace,vLightDirOS));
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=OUT.vLightDirTS+OUT.vEyeDirTS;

	//OUT.Diffuse.rgb=CalculateDebugColor(IN.v4Diffuse.rgb*v4DiffuseColor.rgb*fLightIntensity);

	OUT.Ambient=IN.v4Ambient;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a;
	float4 specular = float4(0,0,0,0);
#ifdef SPECULARENABLED
	specular = v4SpecularColor;
#endif
	OUT.Specular = specular;
	
#ifdef SCROLLENABLED
	float2 fEngineTime=gm_vScrollPosition;
#else
	float fEngineTime=0.0;
#endif
	OUT.vTexCoords1.xy=(IN.vTexCoords.xy+fEngineTime*1.0*float2(1,0))*1.00;
	OUT.vTexCoords1.zw=(IN.vTexCoords.yx+fEngineTime*1.0*float2(1,0))*1.00;
	OUT.vTexCoords2.xy=(IN.vTexCoords.xy-fEngineTime*1.2*float2(0,1))*1.03;
	OUT.vTexCoords2.zw=(IN.vTexCoords.yx-fEngineTime*1.2*float2(0,1))*1.03;
	
	OUT.vTexCoordsProj=mul(m44ViewProjScale,worldPos);
	
	OUT.Position = mul(m44ViewProj, worldPos);
	CalculateFog(OUT.vFog,IN.v4Position/*dot(worldPos,m44ModelView[2])*/);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	
	float3 v3BumpNormal;
#ifdef BUMPENABLED
	float3 vNormal1=tosigned(tex2D(samplerNormal,IN.vTexCoords1.xy).agb)*v4BumpScale;
	float3 vNormal2=tosigned(tex2D(samplerNormal,IN.vTexCoords1.zw).agb)*v4BumpScale;
	float3 vNormal3=tosigned(tex2D(samplerNormal,IN.vTexCoords2.xy).agb)*v4BumpScale;
	float3 vNormal4=tosigned(tex2D(samplerNormal,IN.vTexCoords2.zw).agb)*v4BumpScale;
	v3BumpNormal=(vNormal1+vNormal2+vNormal3+vNormal4)*0.25;
	v3BumpNormal.z=sqrt(1-dot(v3BumpNormal.xy,v3BumpNormal.xy));
#else
	v3BumpNormal=float3(0,0,1);
#endif
	
	float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	float fCosAngleEye=abs(dot(v3BumpNormal,vEyeDirTS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
		
	// @hs Optimize to be a tex2DProj(coords+offset*coords.w instead
	float2 vCoords=IN.vTexCoordsProj.xy/IN.vTexCoordsProj.w;
	
	float4 cReflect=0;
#ifdef REFLECTION2DENABLED
	float2 vReflectOffset=v3BumpNormal*gm_vReflection2DScale;
	cReflect=tex2D(samplerReflection2D,vCoords+vReflectOffset)*gm_vReflection2DColor;
#endif
#ifdef SPECULARENABLED
	float4 cSpecular=v4SpecularColor;
	float fSpecularIntensity=pow(saturate(dot(normalize(IN.vHalfDirTS),v3BumpNormal)),v4SpecularPower.x)*vSpecularLevel;
	cReflect+=cSpecular*fSpecularIntensity;
#endif
	
#ifdef REFRACTION2DENABLED
	float4 cRefract,cRefractOrig,cRefractDistort;
	float2 vRefractOffset=v3BumpNormal.xy*gm_vRefraction2DScale;
	cRefractDistort=tex2D(samplerRefraction2D,vCoords-vRefractOffset);
	cRefractOrig=tex2D(samplerRefraction2D,vCoords);
	if (cRefractDistort.a>0.9)
		cRefract = cRefractDistort;
	else
		cRefract = cRefractOrig;
	cRefract *= gm_vRefraction2DColor;
#endif
	
#if defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)
	OUT.col=lerp(cRefract,cReflect,fFresnel);
#elif defined(REFLECTION2DENABLED)
	OUT.col=lerp(0,cReflect,fFresnel);
#elif defined(REFRACTION2DENABLED)
	OUT.col=cRefract;
#endif

	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fRefractionMask {
	float4 Position:		POSITION;
};
v2fRefractionMask RefractionMask_VS20(a2vWaterPatchHQ IN)
{
	v2fRefractionMask OUT;
	CalcPosition(OUT.Position, IN.v4Position);
	return OUT;
}
f2sStandard RefractionMask_PS20(v2fRefractionMask IN) 
{
	f2sStandard OUT;
	OUT.col.rgb = float3(0,0,0);
	OUT.col.a=1;
	return OUT;
}
technique RefractionMaskHQ_VS20_PS20 < string Identifier="RefractionMask"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 RefractionMask_VS20();
		PixelShader=compile ps_1_1 RefractionMask_PS20();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}

technique RefractionMaskFFP < string Identifier="RefractionMask"; string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 RefractionMask_VS20();
		PixelShader=NULL;
		
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;		
		
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardAmbientHQ11 {
	float4 Position			: POSITION;
	float3 vEyeDirTS		: COLOR0;
	float2 TexNormalCoords	: TEXCOORD0;
#if REFRACTION2DENABLED
	float4 TexRefractProj	: TEXCOORD1;
#endif
#if REFLECTION2DENABLED
	float4 TexReflectProj	: TEXCOORD2;
#endif
#ifdef FOGENABLED
	float vFog				: FOG;
#endif
};

v2fStandardAmbientHQ11 AmbientHQ_VS11(a2vWaterPatchHQ IN)
{
	v2fStandardAmbientHQ11 OUT;
	float4  	sines, cosines;
	float3 		normal = IN.v4Dynamics.xyz;
	float3		tangent,binormal;
	float3x3 	m33TangentSpace;
	float2   	vParallaxScale;
	
	float4 worldPos=mul(m44World,IN.v4Position);
	float4 fSWArg = worldPos.x * v4WaterPatchSineWaves[0] + worldPos.z * v4WaterPatchSineWaves[1] + v4WaterPatchSineWaves[3];
	sincos(fSWArg, sines, cosines);
	
	// height = Ai*sin(Pi*x + Qi*z + Ri)
	worldPos.y += dot(v4WaterPatchSineWaves[2], sines);
	worldPos.y += IN.v4Dynamics.w;	// add the contribution from the ripples 
	
	// NOR = (-Ai pi cos (pi x + qi z + ri), 1 , -Ai qi cos (pi x + qi z + ri);
	normal.x -= dot(v4WaterPatchSineWaves[0] * v4WaterPatchSineWaves[2], cosines);
	normal.y = 1.f;
	normal.z -= dot(v4WaterPatchSineWaves[1] * v4WaterPatchSineWaves[2], cosines);
	CalculateTangentSpace(m33TangentSpace,IN.v3Tangent,IN.v3Binormal,normal);
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));	
#ifdef SCROLLENABLED
	float2 fEngineTime=gm_vScrollPosition;
#else
	float fEngineTime=0.0;
#endif
	OUT.TexNormalCoords.xy=(IN.vTexCoords.xy+fEngineTime*1.0*float2(1,0))*1.00;
	float4 TexProj=mul(m44WorldViewProjScale,IN.v4Position);
#if REFRACTION2DENABLED
	OUT.TexRefractProj.xyzw=TexProj.xyzw;
#endif
#if REFLECTION2DENABLED
	OUT.TexReflectProj.xyzw=TexProj.xyzw;
#endif
	OUT.Position = mul(m44ViewProj, worldPos);
	return OUT;
}

technique Ambient_VS11_PS11 < string Identifier="Ambient"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS11();
		PixelShader = asm {
			ps.1.1
			def		c1,0.0,0.0,1.0,0.5	//v3BumpNormal
			def		c7,0.0,0.0,0.0,0.0
			
#ifdef BUMPENABLED
			tex		t0	//samplerNormal
#endif
#ifdef REFRACTION2DENABLED
			tex		t1		//samplerrefraction
#endif
#ifdef REFLECTION2DENABLED
			tex		t2		//samplerreflection
#endif
#ifdef BUMPENABLED
			mad_sat r0.rgb, t0, c0, c1			//multiply by v4BumpScale and force z to 1
#else
			mov		r0.rgb, c1
#endif
			dp3_d2	r1.rgba,r0,		v0			//float fCosAngleEye=abs(dot(v3BumpNormal.xyz,IN.vEyeDirTS.xyz));
#if defined(REFRACTION2DENABLED)
			mul		t1.rgb,	t1,		c6			//cRefract
//			+add_d2	r0.a,	r1.a,	c1.a		
#else
//			add_d2	r0.a,	r1.a,	c1.a		
#endif
//			cnd		r0,		r0.a,	r1,		-r1	//abs - not currently used
			
			dp3_d2	r0.rgba,r1,		c2			//float fresnelTerm=dot(v4SpecularPower.xzy, fCosAngleEye.xxx);
			
#if defined(REFLECTION2DENABLED)
			mul		t2.rgb,	t2,		c5				//cReflect
			+mad_sat r0.a,	r1.a,	c2.a,	r0.a	//float fFresnel=v4SpecularPower.a*fCosAngleEye+fresnelTerm;
#else
			mad_sat r0.a,	r1.a,	c2.a,	r0.a	//float fFresnel=v4SpecularPower.a*fCosAngleEye+fresnelTerm;
#endif
			
			lrp_sat	r0.rgba,r0.a,	c3,		c4		//fFresnel=lerp(gm_vFresnelMax, gm_vFresnelMin, 1-fFresnel);

#if defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)
			lrp		r0.rgb, r0.a,	t2,		t1	//OUT.col.rgb=lerp(cRefract,cReflect,fFresnel);
#elif defined(REFLECTION2DENABLED)
			lrp		r0.rgb, r0.a,	t2,		c7	//OUT.col.rgb=lerp(0,cReflect,fFresnel);
#elif defined(REFRACTION2DENABLED)
			mov		r0.rgb, t1					//OUT.col.rgb=cRefract;
#endif
			+mov	r0.a,	c1.a			//OUT.col.a=1;
		};
		
		PixelShaderConstant[0]=<v4BumpScale>;
		//PixelShaderConstant[1]=float3(0,0,1,1);				//reserved (defined directly in the shader)
		PixelShaderConstant[2]=<v4SpecularPower>;
		PixelShaderConstant[3]=<gm_vFresnelMin>;
		PixelShaderConstant[4]=<gm_vFresnelMax>;
#ifdef REFLECTION2DENABLED
		PixelShaderConstant[5]=<gm_vReflection2DColor>;
#endif
#ifdef REFRACTION2DENABLED
		PixelShaderConstant[6]=<gm_vRefraction2DColor>;
#endif	
		//PixelShaderConstant[7]=float4(0.0,0.0,0.0,0.0);	//reserved (defined directly in the shader)

		SpecularEnable=false;
		
#ifdef BUMPENABLED
		Texture[0] = <mapNormal>;		//samplerNormal
		TEXTURETRANSFORMFLAGS[0]=0;
#endif
#ifdef REFRACTION2DENABLED
		Texture[1] = <mapRefraction2D>;	//samplerrefraction
		TEXTURETRANSFORMFLAGS[1] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
#endif
#ifdef REFLECTION2DENABLED
		Texture[2] = <mapReflection2D>;	//samplerreflection
		TEXTURETRANSFORMFLAGS[2] = 256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
#endif
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=None;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
#ifdef FOGENABLED
		FogColor=<vFogColor>;
#endif
	}
}

struct v2WaterAmbient10 {
	float4 Position			: POSITION;
	float3 Diffuse			: COLOR0;
#if defined(REFLECTION2DENABLED) && !defined(REFRACTION2DENABLED)		// only reflection
	float4 TexReflectProj	: TEXCOORD0;
#endif

#if !defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)		// only refraction
	float4 TexRefractProj	: TEXCOORD0;
#endif

#if defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)		// reflection + refraction
	float4 TexRefractProj	: TEXCOORD0;
	float4 TexReflectProj	: TEXCOORD1;
#endif
	float vFog:				FOG;
};

v2WaterAmbient10 AmbientHQ_VS10(a2vWaterPatchHQ IN)
{
	v2WaterAmbient10 OUT;
	float4  	sines, cosines;
	float3 		normal = IN.v4Dynamics.xyz;
	float3x3 	m33TangentSpace;
	
	float4 worldPos=mul(m44World,IN.v4Position);
	float4 fSWArg = worldPos.x * v4WaterPatchSineWaves[0] + worldPos.z * v4WaterPatchSineWaves[1] + v4WaterPatchSineWaves[3];
	sincos(fSWArg, sines, cosines);
	
	// height = Ai*sin(Pi*x + Qi*z + Ri)
	worldPos.y += dot(v4WaterPatchSineWaves[2], sines);
	worldPos.y += IN.v4Dynamics.w;	// add the contribution from the ripples 
	
	// NOR = (-Ai pi cos (pi x + qi z + ri), 1 , -Ai qi cos (pi x + qi z + ri);
	normal.x -= dot(v4WaterPatchSineWaves[0] * v4WaterPatchSineWaves[2], cosines);
	normal.y = 1.f;
	normal.z -= dot(v4WaterPatchSineWaves[1] * v4WaterPatchSineWaves[2], cosines);

	float3 vEyeDirOS=normalize(v4EyePosObject.xyz-IN.v4Position.xyz);
	float fCosAngleEye=abs(dot(normal,vEyeDirOS));
	float fFresnel=CalculateFresnelTerm(fCosAngleEye);
	float4 TexProj=mul(m44WorldViewProjScale,IN.v4Position);
#if REFRACTION2DENABLED
	OUT.TexRefractProj.xyzw=TexProj.xyzw;
#endif
#if REFLECTION2DENABLED
	OUT.TexReflectProj.xyzw=TexProj.xyzw;
#endif
	OUT.Position = mul(m44ViewProj, worldPos);
	
	CalculateFog(OUT.vFog,IN.v4Position/*dot(worldPos,m44ModelView[2])*/);
	OUT.Diffuse=IN.vLightCol+IN.v4Ambient;
	return OUT;
}

technique Ambient_VS11_PS00 < string Identifier="Ambient"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS10();
		PixelShader = NULL;

		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=None;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
#ifdef FOGENABLE
		FogColor=<vFogColor>;
#endif

#if defined(REFLECTION2DENABLED) && !defined(REFRACTION2DENABLED)
		Sampler[0]=<samplerReflection2D>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		ColorOp[2]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;

#endif

#if !defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)
		Sampler[0]=<samplerRefraction2D>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		ColorOp[2]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;

#endif

#if defined(REFLECTION2DENABLED) && defined(REFRACTION2DENABLED)
		Sampler[0]=<samplerRefraction2D>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflection2D>;
		ColorOp[1]=LERP;
		ColorArg0[1]=DIFFUSE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		ColorOp[2]=DISABLE;
		
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG1;
		AlphaArg0[1]=CURRENT|COMPLEMENT;	//one
		AlphaArg1[1]=DIFFUSE;
		AlphaOp[2]=DISABLE;

		TEXTURETRANSFORMFLAGS[0]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[1]=256;	//D3DTSS_TEXTURETRANSFORMFLAGS = D3DTTFF_PROJECTED
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;

#endif
	}
}